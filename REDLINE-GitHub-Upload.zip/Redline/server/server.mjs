import http from 'node:http';
import { readFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import { randomBytes, randomUUID } from 'node:crypto';
import { WebSocketServer, WebSocket } from 'ws';
import { validSnapshot, MAPS } from '../src/core.mjs';

const ROOT=path.resolve(fileURLToPath(new URL('../web/',import.meta.url)));
const MIME={'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'application/javascript; charset=utf-8','.png':'image/png'};
export function createGameServer(){
  const rooms=new Map();
  const server=http.createServer(async(req,res)=>{
    let pathname;try{pathname=decodeURIComponent(new URL(req.url,'http://localhost').pathname);}catch{res.writeHead(400);return res.end();}
    if(pathname==='/health'){res.writeHead(200,{'content-type':'application/json'});return res.end(JSON.stringify({ok:true,rooms:rooms.size}));}
    const file=path.resolve(ROOT,'.'+(pathname==='/'?'/index.html':pathname));
    if(!file.startsWith(ROOT+path.sep)){res.writeHead(403);return res.end();}
    try{const bytes=await readFile(file);res.writeHead(200,{'content-type':MIME[path.extname(file)]||'application/octet-stream','cache-control':'no-cache','x-content-type-options':'nosniff','referrer-policy':'no-referrer'});res.end(bytes);}catch{res.writeHead(404);res.end('Not found');}
  });
  const wss=new WebSocketServer({server,path:'/multiplayer',maxPayload:4096,perMessageDeflate:false});
  const send=(ws,m)=>{if(ws.readyState===WebSocket.OPEN)ws.send(JSON.stringify(m));};
  const broadcast=(room,m,exclude)=>{for(const ws of room.clients)if(ws!==exclude)send(ws,m);};
  function remove(ws){
    const room=rooms.get(ws.room);if(!room)return;room.clients.delete(ws);broadcast(room,{type:'peerLeave',id:ws.id});
    if(!room.clients.size)rooms.delete(ws.room);ws.room=null;
  }
  wss.on('connection',ws=>{
    ws.id=randomUUID();ws.room=null;ws.alive=true;ws.bucket=60;ws.refill=Date.now();
    ws.on('pong',()=>{ws.alive=true;});
    const joinDeadline=setTimeout(()=>{if(!ws.room)ws.close(1008,'Join timeout');},15000);
    ws.on('message',raw=>{
      const now=Date.now();ws.bucket=Math.min(60,ws.bucket+(now-ws.refill)*.03);ws.refill=now;
      if(--ws.bucket<0){ws.close(1008,'Rate limit');return;}
      let m;try{m=JSON.parse(raw.toString());}catch{return;}
      if(!m||typeof m!=='object')return;
      if(m.type==='create'||m.type==='join'){
        if(ws.room)return;
        let code,room;
        if(m.type==='create'){
          if(!Object.hasOwn(MAPS,m.map))return send(ws,{type:'error',message:'Choose a valid map.'});
          if(rooms.size>=200)return send(ws,{type:'error',message:'Server full. Try again later.'});
          do{code=randomBytes(3).toString('hex').toUpperCase();}while(rooms.has(code));
          room={map:m.map,clients:new Set()};rooms.set(code,room);
        }else{
          code=typeof m.room==='string'?m.room.toUpperCase():'';room=rooms.get(code);
          if(!room)return send(ws,{type:'error',message:'Room not found. Check the six-character code.'});
          if(room.clients.size>=4)return send(ws,{type:'error',message:'This room already has four riders.'});
        }
        ws.name=(typeof m.name==='string'?m.name:'Rider').replace(/[\x00-\x1f\x7f]/g,'').trim().slice(0,20)||'Rider';
        ws.room=code;clearTimeout(joinDeadline);
        const peers=[...room.clients].map(p=>({id:p.id,name:p.name}));
        send(ws,{type:'welcome',id:ws.id,room:code,map:room.map,peers});
        broadcast(room,{type:'peerJoin',id:ws.id,name:ws.name});room.clients.add(ws);
        for(const p of room.clients)if(p!==ws&&p.lastState)send(ws,{type:'state',id:p.id,state:p.lastState});
      }else if(m.type==='state'){
        const room=rooms.get(ws.room);if(!room||!validSnapshot(m.state,room.map))return;
        ws.lastState={...m.state,name:ws.name};broadcast(room,{type:'state',id:ws.id,state:ws.lastState},ws);
      }
    });
    ws.on('close',()=>{clearTimeout(joinDeadline);remove(ws);});ws.on('error',()=>{});
  });
  const pulse=setInterval(()=>{for(const ws of wss.clients){if(!ws.alive){ws.terminate();continue;}ws.alive=false;ws.ping();}},20000);pulse.unref();
  const close=async()=>{clearInterval(pulse);for(const ws of wss.clients)ws.terminate();await new Promise(r=>wss.close(r));await new Promise(r=>server.close(r));};
  return {server,wss,rooms,close};
}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url)){
  const game=createGameServer(),port=Number(process.env.PORT)||8080;
  game.server.listen(port,process.env.HOST||'0.0.0.0',()=>console.log(`REDLINE ready at http://localhost:${port} — up to 4 riders per room`));
  for(const signal of ['SIGINT','SIGTERM'])process.on(signal,()=>game.close().then(()=>process.exit(0)));
}
