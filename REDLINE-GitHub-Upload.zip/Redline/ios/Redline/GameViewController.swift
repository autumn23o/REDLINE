import UIKit
import WebKit
import GameKit
import AVFAudio

/// Local WebGL game + native Game Center transport. No remote web content is loaded.
final class GameViewController: UIViewController, WKScriptMessageHandler, WKNavigationDelegate, GKMatchmakerViewControllerDelegate, GKMatchDelegate, GKLocalPlayerListener {
    private var webView: WKWebView!
    private var gameMatch: GKMatch?
    private var selectedMap = "coast"
    private let validMaps = ["coast", "city", "desert"]
    private var webReady = false
    private var didStartMatch = false
    private var proposals: [String: String] = [:]
    private var handshakeTimer: Timer?
    private var handshakeAttempts = 0
    private var lastStateReceived: [String: TimeInterval] = [:]
    private var pendingMatch = false
    private var authenticationStarted = false
    private var lastSendErrorAt: TimeInterval = 0

    override var prefersStatusBarHidden: Bool { true }
    override var prefersHomeIndicatorAutoHidden: Bool { true }
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask { .landscape }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor(red: 0.07, green: 0.13, blue: 0.15, alpha: 1)
        let config = WKWebViewConfiguration()
        config.allowsInlineMediaPlayback = true
        config.mediaTypesRequiringUserActionForPlayback = []
        config.userContentController.add(self, name: "redline")
        webView = WKWebView(frame: .zero, configuration: config)
        webView.navigationDelegate = self
        webView.isOpaque = false
        webView.backgroundColor = view.backgroundColor
        webView.scrollView.isScrollEnabled = false
        webView.scrollView.bounces = false
        webView.scrollView.contentInsetAdjustmentBehavior = .never
        webView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(webView)
        NSLayoutConstraint.activate([
            webView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            webView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            webView.topAnchor.constraint(equalTo: view.topAnchor),
            webView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
        try? AVAudioSession.sharedInstance().setCategory(.ambient, mode: .default)
        UIApplication.shared.isIdleTimerDisabled = true
        if let url = Bundle.main.url(forResource: "index", withExtension: "html", subdirectory: "Web") {
            webView.loadFileURL(url, allowingReadAccessTo: url.deletingLastPathComponent())
        } else {
            webView.loadHTMLString("<body style='background:#12252b;color:white;font-family:system-ui;padding:40px'><h1>Game assets are missing.</h1><p>Run npm run build before building the app.</p></body>", baseURL: nil)
        }
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        if !authenticationStarted { authenticate() }
    }

    func pauseGame() { emit(["type": "paused"]) }

    private func emit(_ object: [String: Any]) {
        guard webReady, JSONSerialization.isValidJSONObject(object),
              let data = try? JSONSerialization.data(withJSONObject: object),
              let json = String(data: data, encoding: .utf8) else { return }
        webView.evaluateJavaScript("window.RedlineNative && window.RedlineNative.receive(\(json));", completionHandler: nil)
    }

    private func failure(_ message: String) { emit(["type": "error", "message": message]) }

    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        guard message.frameInfo.isMainFrame, let body = message.body as? [String: Any], let action = body["action"] as? String else { return }
        switch action {
        case "ready":
            webReady = true
            emit(["type": "auth", "authenticated": GKLocalPlayer.local.isAuthenticated])
        case "match":
            guard let map = body["map"] as? String, validMaps.contains(map) else { return }
            selectedMap = map
            if GKLocalPlayer.local.isAuthenticated { presentMatchmaker() }
            else { pendingMatch = true; authenticate() }
        case "state":
            guard didStartMatch, let state = body["state"] as? [String: Any], state["map"] as? String == selectedMap else { return }
            send(["kind": "state", "state": state], reliable: false)
        case "leave": leaveMatch(notify: false)
        default: break
        }
    }

    private func authenticate() {
        authenticationStarted = true
        GKLocalPlayer.local.authenticateHandler = { [weak self] controller, error in
            DispatchQueue.main.async {
                guard let self else { return }
                if let controller {
                    if self.presentedViewController == nil { self.present(controller, animated: true) }
                    return
                }
                let local = GKLocalPlayer.local
                if local.isAuthenticated {
                    local.unregisterListener(self)
                    local.register(self)
                    self.emit(["type": "auth", "authenticated": true])
                    if self.pendingMatch {
                        self.pendingMatch = false
                        // Authentication UI may still be completing dismissal.
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.6) { [weak self] in self?.presentMatchmaker() }
                    }
                } else {
                    let wasPending = self.pendingMatch
                    self.pendingMatch = false
                    self.emit(["type": "auth", "authenticated": false])
                    if wasPending { self.failure(error?.localizedDescription ?? "Sign in to Game Center in iPhone Settings, then try again.") }
                    if self.gameMatch != nil { self.leaveMatch(notify: true) }
                }
            }
        }
    }

    private func presentMatchmaker() {
        guard GKLocalPlayer.local.isAuthenticated else { failure("Sign in to Game Center to play online."); return }
        guard !GKLocalPlayer.local.isMultiplayerGamingRestricted else { failure("Multiplayer is restricted for this Game Center account."); return }
        guard presentedViewController == nil else { failure("Close the current Game Center screen, then try again."); return }
        leaveMatch(notify: false)
        let request = GKMatchRequest()
        request.minPlayers = 2
        request.maxPlayers = 4
        request.defaultNumberOfPlayers = 2
        request.playerGroup = 100 + (validMaps.firstIndex(of: selectedMap) ?? 0)
        guard let controller = GKMatchmakerViewController(matchRequest: request) else { failure("Game Center matchmaking could not open."); return }
        controller.matchmakerDelegate = self
        present(controller, animated: true)
    }

    func matchmakerViewControllerWasCancelled(_ viewController: GKMatchmakerViewController) {
        viewController.dismiss(animated: true)
        failure("Matchmaking cancelled. You can ride solo or try again.")
    }

    func matchmakerViewController(_ viewController: GKMatchmakerViewController, didFailWithError error: Error) {
        viewController.dismiss(animated: true)
        failure(error.localizedDescription)
    }

    func matchmakerViewController(_ viewController: GKMatchmakerViewController, didFind match: GKMatch) {
        viewController.dismiss(animated: true)
        gameMatch = match
        match.delegate = self
        didStartMatch = false
        proposals = [GKLocalPlayer.local.gamePlayerID: selectedMap]
        handshakeAttempts = 0
        handshakeTimer?.invalidate()
        // Reliable retries cover peers whose native delegate is not yet installed.
        handshakeTimer = Timer.scheduledTimer(withTimeInterval: 0.75, repeats: true) { [weak self] _ in
            guard let self, !self.didStartMatch else { return }
            self.handshakeAttempts += 1
            if self.handshakeAttempts > 30 {
                self.leaveMatch(notify: true)
                self.failure("Riders could not synchronize. Please start a new match.")
                return
            }
            self.send(["kind": "hello", "version": 1, "map": self.selectedMap], reliable: true)
            self.beginIfLeaderReady()
        }
        send(["kind": "hello", "version": 1, "map": selectedMap], reliable: true)
    }

    private var leader: String? {
        guard let gameMatch else { return nil }
        return ([GKLocalPlayer.local.gamePlayerID] + gameMatch.players.map(\.gamePlayerID)).sorted().first
    }

    private func beginIfLeaderReady() {
        guard let match = gameMatch, leader == GKLocalPlayer.local.gamePlayerID,
              match.expectedPlayerCount == 0, !match.players.isEmpty,
              match.players.allSatisfy({ proposals[$0.gamePlayerID] != nil }) else { return }
        send(["kind": "start", "version": 1, "map": selectedMap], reliable: true)
        begin(map: selectedMap)
    }

    private func begin(map: String) {
        guard !didStartMatch, validMaps.contains(map), let match = gameMatch else { return }
        selectedMap = map
        didStartMatch = true
        handshakeTimer?.invalidate()
        handshakeTimer = nil
        let peers = match.players.map { ["id": $0.gamePlayerID, "name": String($0.displayName.prefix(20))] }
        emit(["type": "connected", "id": GKLocalPlayer.local.gamePlayerID, "map": map, "peers": peers])
    }

    private func send(_ payload: [String: Any], reliable: Bool) {
        guard let match = gameMatch, JSONSerialization.isValidJSONObject(payload),
              let data = try? JSONSerialization.data(withJSONObject: payload), data.count <= 4096 else { return }
        do { try match.sendData(toAllPlayers: data, with: reliable ? .reliable : .unreliable) }
        catch {
            let now = Date.timeIntervalSinceReferenceDate
            if now - lastSendErrorAt > 5 { lastSendErrorAt = now; failure("Connection interrupted: \(error.localizedDescription)") }
        }
    }

    func match(_ match: GKMatch, didReceive data: Data, fromRemotePlayer player: GKPlayer) {
        guard data.count <= 4096, let payload = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else { return }
        DispatchQueue.main.async { [weak self] in
            guard let self, self.gameMatch === match, match.players.contains(where: { $0.gamePlayerID == player.gamePlayerID }), let kind = payload["kind"] as? String else { return }
            if kind == "hello", payload["version"] as? Int == 1, let map = payload["map"] as? String, self.validMaps.contains(map) {
                self.proposals[player.gamePlayerID] = map
                if self.didStartMatch && self.leader == GKLocalPlayer.local.gamePlayerID {
                    self.send(["kind": "start", "version": 1, "map": self.selectedMap], reliable: true)
                } else { self.beginIfLeaderReady() }
            } else if kind == "start", payload["version"] as? Int == 1, player.gamePlayerID == self.leader, let map = payload["map"] as? String {
                self.begin(map: map)
            } else if kind == "state", self.didStartMatch, var state = payload["state"] as? [String: Any], state["map"] as? String == self.selectedMap {
                let now = Date.timeIntervalSinceReferenceDate
                guard now - (self.lastStateReceived[player.gamePlayerID] ?? 0) > 0.025 else { return }
                self.lastStateReceived[player.gamePlayerID] = now
                state["name"] = String(player.displayName.prefix(20))
                self.emit(["type": "state", "id": player.gamePlayerID, "state": state])
            }
        }
    }

    func match(_ match: GKMatch, player: GKPlayer, didChange state: GKPlayerConnectionState) {
        DispatchQueue.main.async { [weak self] in
            guard let self, self.gameMatch === match else { return }
            switch state {
            case .connected:
                if self.didStartMatch { self.emit(["type": "peerJoin", "id": player.gamePlayerID, "name": String(player.displayName.prefix(20))]) }
                self.beginIfLeaderReady()
            case .disconnected:
                self.proposals.removeValue(forKey: player.gamePlayerID)
                self.lastStateReceived.removeValue(forKey: player.gamePlayerID)
                self.emit(["type": "peerLeave", "id": player.gamePlayerID])
                if match.players.isEmpty { self.leaveMatch(notify: true) }
            default: break
            }
        }
    }

    func match(_ match: GKMatch, didFailWithError error: Error?) {
        DispatchQueue.main.async { [weak self] in
            guard let self, self.gameMatch === match else { return }
            self.leaveMatch(notify: true)
            self.failure(error?.localizedDescription ?? "The multiplayer connection ended.")
        }
    }

    func player(_ player: GKPlayer, didAccept invite: GKInvite) {
        DispatchQueue.main.async { [weak self] in
            guard let self else { return }
            self.pauseGame()
            self.leaveMatch(notify: false)
            let show = {
                guard let controller = GKMatchmakerViewController(invite: invite) else { self.failure("This invitation is no longer available."); return }
                controller.matchmakerDelegate = self
                self.present(controller, animated: true)
            }
            if self.presentedViewController != nil { self.dismiss(animated: true, completion: show) } else { show() }
        }
    }

    private func leaveMatch(notify: Bool) {
        handshakeTimer?.invalidate()
        handshakeTimer = nil
        gameMatch?.delegate = nil
        gameMatch?.disconnect()
        gameMatch = nil
        didStartMatch = false
        proposals.removeAll()
        lastStateReceived.removeAll()
        if notify { emit(["type": "disconnected", "message": "Game Center session ended. Continue riding solo."]) }
    }

    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        guard let url = navigationAction.request.url else { decisionHandler(.cancel); return }
        decisionHandler(url.isFileURL || url.absoluteString == "about:blank" ? .allow : .cancel)
    }

    func webViewWebContentProcessDidTerminate(_ webView: WKWebView) {
        leaveMatch(notify: false)
        webReady = false
        webView.reload()
    }
}
