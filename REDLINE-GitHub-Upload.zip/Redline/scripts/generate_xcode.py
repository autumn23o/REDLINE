"""Regenerate the dependency-free Xcode project. Run from any directory."""
from pathlib import Path
import hashlib
import json
import re

root = Path(__file__).resolve().parent.parent
project = root / 'ios/Redline.xcodeproj'
project.mkdir(parents=True, exist_ok=True)
def uid(name): return hashlib.sha256(name.encode()).hexdigest()[:24].upper()
def q(s): return json.dumps(s)
objects = {}
def obj(name, body):
    kind = re.search(r'isa = (\w+);', body).group(1)
    objects.setdefault(kind, []).append(f'\t\t{uid(name)} = {{ {body} }};')
    return uid(name)

swift = ['AppDelegate.swift', 'SceneDelegate.swift', 'GameViewController.swift']
resources = ['Web', 'Assets.xcassets', 'PrivacyInfo.xcprivacy']
files = swift + resources + ['Info.plist', 'Redline.entitlements']
types = {'.swift':'sourcecode.swift', '.plist':'text.plist.xml', '.entitlements':'text.plist.entitlements', '.xcprivacy':'text.xml', '.xcassets':'folder.assetcatalog'}
for name in files:
    typ = 'folder' if name == 'Web' else types[Path(name).suffix]
    obj('file/'+name, f'isa = PBXFileReference; lastKnownFileType = {q(typ)}; path = {q(name)}; sourceTree = "<group>";')
for name in swift + resources:
    obj('build/'+name, f'isa = PBXBuildFile; fileRef = {uid("file/"+name)};')
obj('product', 'isa = PBXFileReference; explicitFileType = wrapper.application; includeInIndex = 0; path = Redline.app; sourceTree = BUILT_PRODUCTS_DIR;')
obj('products', f'isa = PBXGroup; children = ({uid("product")},); name = Products; sourceTree = "<group>";')
obj('source', f'isa = PBXGroup; children = ({",".join(uid("file/"+n) for n in files)},); path = Redline; sourceTree = "<group>";')
obj('rootgroup', f'isa = PBXGroup; children = ({uid("source")},{uid("products")},); sourceTree = "<group>";')
for name,isa,items in [('sources','PBXSourcesBuildPhase',swift),('resources','PBXResourcesBuildPhase',resources),('frameworks','PBXFrameworksBuildPhase',[])]:
    ids=','.join(uid('build/'+n) for n in items)
    obj(name,f'isa = {isa}; buildActionMask = 2147483647; files = ({ids}{"," if ids else ""}); runOnlyForDeploymentPostprocessing = 0;')

common_project = {'ALWAYS_SEARCH_USER_PATHS':'NO','CLANG_ENABLE_MODULES':'YES','CLANG_ENABLE_OBJC_ARC':'YES','IPHONEOS_DEPLOYMENT_TARGET':'16.0','SDKROOT':'iphoneos','SWIFT_VERSION':'5.0','SWIFT_STRICT_CONCURRENCY':'minimal','CLANG_WARN_DOCUMENTATION_COMMENTS':'YES','CLANG_WARN_UNREACHABLE_CODE':'YES','ENABLE_STRICT_OBJC_MSGSEND':'YES','GCC_C_LANGUAGE_STANDARD':'gnu17'}
common_target = {'ASSETCATALOG_COMPILER_APPICON_NAME':'AppIcon','CODE_SIGN_ENTITLEMENTS':'Redline/Redline.entitlements','CODE_SIGN_STYLE':'Automatic','CURRENT_PROJECT_VERSION':'1','GENERATE_INFOPLIST_FILE':'NO','INFOPLIST_FILE':'Redline/Info.plist','IPHONEOS_DEPLOYMENT_TARGET':'16.0','MARKETING_VERSION':'1.0.0','PRODUCT_BUNDLE_IDENTIFIER':'com.yourstudio.redline','PRODUCT_NAME':'$(TARGET_NAME)','SUPPORTED_PLATFORMS':'iphoneos iphonesimulator','SUPPORTS_MACCATALYST':'NO','TARGETED_DEVICE_FAMILY':'1,2','SWIFT_VERSION':'5.0','SWIFT_EMIT_LOC_STRINGS':'YES','ENABLE_USER_SCRIPT_SANDBOXING':'YES'}
for scope,common in [('project',common_project),('target',common_target)]:
    for config in ['Debug','Release']:
        settings = dict(common)
        settings.update({'SWIFT_OPTIMIZATION_LEVEL':'-Onone' if config=='Debug' else '-O','DEBUG_INFORMATION_FORMAT':'dwarf' if config=='Debug' else 'dwarf-with-dsym'})
        if config=='Debug': settings.update({'ENABLE_TESTABILITY':'YES','SWIFT_ACTIVE_COMPILATION_CONDITIONS':'DEBUG','ONLY_ACTIVE_ARCH':'YES'})
        else: settings['SWIFT_COMPILATION_MODE']='wholemodule'
        body=' '.join(f'{key} = {q(val)};' for key,val in settings.items())
        obj(scope+config,f'isa = XCBuildConfiguration; buildSettings = {{ {body} }}; name = {config};')
    obj(scope+'configs',f'isa = XCConfigurationList; buildConfigurations = ({uid(scope+"Debug")},{uid(scope+"Release")},); defaultConfigurationIsVisible = 0; defaultConfigurationName = Release;')
obj('target',f'isa = PBXNativeTarget; buildConfigurationList = {uid("targetconfigs")}; buildPhases = ({uid("sources")},{uid("frameworks")},{uid("resources")},); buildRules = (); dependencies = (); name = Redline; productName = Redline; productReference = {uid("product")}; productType = "com.apple.product-type.application";')
obj('project',f'isa = PBXProject; attributes = {{ LastUpgradeCheck = 1600; TargetAttributes = {{ {uid("target")} = {{ CreatedOnToolsVersion = 16.0; SystemCapabilities = {{ com.apple.GameCenter = {{ enabled = 1; }}; }}; }}; }}; }}; buildConfigurationList = {uid("projectconfigs")}; compatibilityVersion = "Xcode 14.0"; developmentRegion = en; hasScannedForEncodings = 0; knownRegions = (en,Base,); mainGroup = {uid("rootgroup")}; productRefGroup = {uid("products")}; projectDirPath = ""; projectRoot = ""; targets = ({uid("target")},);')
sections = '\n'.join(f'/* Begin {kind} section */\n'+ '\n'.join(items)+f'\n/* End {kind} section */' for kind,items in sorted(objects.items()))
(project/'project.pbxproj').write_text('// !$*UTF8*$!\n{\n\tarchiveVersion = 1;\n\tclasses = {};\n\tobjectVersion = 56;\n\tobjects = {\n'+sections+'\n\t};\n\trootObject = '+uid('project')+';\n}\n')
schemes=project/'xcshareddata/xcschemes';schemes.mkdir(parents=True,exist_ok=True)
ref=f'<BuildableReference BuildableIdentifier="primary" BlueprintIdentifier="{uid("target")}" BuildableName="Redline.app" BlueprintName="Redline" ReferencedContainer="container:Redline.xcodeproj"/>'
(schemes/'Redline.xcscheme').write_text(f'''<?xml version="1.0" encoding="UTF-8"?>
<Scheme LastUpgradeVersion="1600" version="1.3">
<BuildAction parallelizeBuildables="YES" buildImplicitDependencies="YES"><BuildActionEntries><BuildActionEntry buildForTesting="YES" buildForRunning="YES" buildForProfiling="YES" buildForArchiving="YES" buildForAnalyzing="YES">{ref}</BuildActionEntry></BuildActionEntries></BuildAction>
<TestAction buildConfiguration="Debug" selectedDebuggerIdentifier="Xcode.DebuggerFoundation.Debugger.LLDB" selectedLauncherIdentifier="Xcode.IDEFoundation.Launcher.LLDB" shouldUseLaunchSchemeArgsEnv="YES"><Testables/></TestAction>
<LaunchAction buildConfiguration="Debug" selectedDebuggerIdentifier="Xcode.DebuggerFoundation.Debugger.LLDB" selectedLauncherIdentifier="Xcode.IDEFoundation.Launcher.LLDB" launchStyle="0" useCustomWorkingDirectory="NO" ignoresPersistentStateOnLaunch="NO" debugDocumentVersioning="YES" debugServiceExtension="internal" allowLocationSimulation="YES"><BuildableProductRunnable runnableDebuggingMode="0">{ref}</BuildableProductRunnable></LaunchAction>
<ProfileAction buildConfiguration="Release" shouldUseLaunchSchemeArgsEnv="YES" savedToolIdentifier="" useCustomWorkingDirectory="NO" debugDocumentVersioning="YES"><BuildableProductRunnable runnableDebuggingMode="0">{ref}</BuildableProductRunnable></ProfileAction>
<AnalyzeAction buildConfiguration="Debug"/><ArchiveAction buildConfiguration="Release" revealArchiveInOrganizer="YES"/>
</Scheme>''')
print(project)
