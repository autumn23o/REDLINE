import { chromium } from 'playwright';
import assert from 'node:assert/strict';
import { mkdir, writeFile } from 'node:fs/promises';
import { createGameServer } from '../server/server.mjs';
import { fileURLToPath } from 'node:url';

const output=fileURLToPath(new URL('../test-results/',import.meta.url));await mkdir(output,{recursive:true});
const game=createGameServer();await new Promise(r=>game.server.listen(0,'127.0.0.1',r));const url=`http://127.0.0.1:${game.server.address().port}`;
const browser=await chromium.launch({headless:true,args:['--no-sandbox','--enable-unsafe-swiftshader','--disable-background-timer-throttling','--disable-renderer-backgrounding']});
const errors=[],results=[];
function watch(page){page.on('pageerror',e=>errors.push(e.message));}
async function ready(page){await page.waitForFunction(()=>window.Redline?.renderStats.frame>2);}
async function checkpoint(name){results.push({name,passed:true});console.log(`PASS ${name}`);}
try{
  const desktop=await browser.newContext({viewport:{width:1440,height:900}}),p=await desktop.newPage();watch(p);await p.goto(url);await ready(p);
  await p.screenshot({path:output+'01-garage.png'});
  await p.click('#help');assert(await p.locator('#got-it').isVisible());await p.click('#got-it');
  await p.click('#ride');await p.keyboard.down('KeyW');await p.waitForFunction(()=>Redline.state.speed>9);await p.keyboard.down('Space');await p.waitForFunction(()=>Redline.state.pitch>.6);
  assert((await p.evaluate(()=>Redline.state)).score>0);await p.screenshot({path:output+'02-wheelie.png'});
  await p.keyboard.up('Space');await p.keyboard.up('KeyW');await p.keyboard.down('KeyS');await p.waitForFunction(()=>Redline.state.speed===0&&Redline.state.pitch<.02);await p.keyboard.up('KeyS');
  await p.click('#pause');const paused=await p.evaluate(()=>Redline.state.lapElapsed);await p.waitForTimeout(150);assert.equal(await p.evaluate(()=>Redline.state.lapElapsed),paused);await p.click('#resume');await p.click('#reset');assert.equal((await p.evaluate(()=>Redline.state)).speed,0);
  await checkpoint('Desktop throttle, wheelie, brake, pause, resume, and reset');
  for(const [map,vehicle] of [['city','kart'],['desert','surron']]){
    await p.click('#pause');await p.click('#to-garage');await p.click(`[data-map="${map}"]`);await p.click(`[data-vehicle="${vehicle}"]`);await p.click('#ride');
    assert.equal(await p.evaluate(()=>Redline.map),map);assert.equal(await p.evaluate(()=>Redline.vehicle),vehicle);
    if(vehicle==='kart')assert(await p.locator('#wheelie').isDisabled());
    await p.keyboard.down('KeyW');await p.waitForFunction(()=>Redline.state.speed>7);await p.keyboard.up('KeyW');
    await p.screenshot({path:output+`03-${map}.png`});assert((await p.evaluate(()=>Redline.renderStats.calls))<150);
  }
  await checkpoint('All three 3D maps and all three vehicle types render and drive');
  await desktop.close();

  const mobile=await browser.newContext({viewport:{width:852,height:393},deviceScaleFactor:1,isMobile:true,hasTouch:true}),m=await mobile.newPage();watch(m);await m.goto(url);await ready(m);
  for(const map of ['city','desert','coast']){await m.tap(`[data-map="${map}"]`);assert.equal(await m.evaluate(()=>Redline.map),map);}
  const mapBottom=await m.locator('[data-map="desert"]').boundingBox(),rideTop=await m.locator('#ride').boundingBox();assert(mapBottom.y+mapBottom.height<=rideTop.y,'map selection overlaps the ride button');
  await m.screenshot({path:output+'04-iphone-garage.png'});await m.tap('#ride');
  const touch=await mobile.newCDPSession(m),g=await m.locator('#gas').boundingBox(),w=await m.locator('#wheelie').boundingBox(),b=await m.locator('#brake').boundingBox();
  const point=(box,id)=>({x:Math.round(box.x+box.width/2),y:Math.round(box.y+box.height/2),id,radiusX:7,radiusY:7,force:1});
  await touch.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[point(g,1)]});await m.waitForFunction(()=>Redline.state.speed>7);
  await touch.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[point(g,1),point(w,2)]});await m.waitForFunction(()=>Redline.state.pitch>.5);
  await m.screenshot({path:output+'05-iphone-wheelie.png'});await touch.send('Input.dispatchTouchEvent',{type:'touchCancel',touchPoints:[]});
  await touch.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[point(b,3)]});await m.waitForFunction(()=>Redline.state.speed===0&&Redline.state.pitch<.02);await touch.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});
  for(const id of ['left','right','wheelie','gas','brake','pause']){const box=await m.locator('#'+id).boundingBox();assert(box&&box.x>=0&&box.y>=0&&box.x+box.width<=853&&box.y+box.height<=394,`${id} outside iPhone viewport`);}
  await checkpoint('iPhone landscape layout, simultaneous gas + wheelie, cancellation, and braking');await mobile.close();

  const ac=await browser.newContext({viewport:{width:1024,height:640}}),bc=await browser.newContext({viewport:{width:1024,height:640}});
  const a=await ac.newPage(),bpage=await bc.newPage();watch(a);watch(bpage);
  await a.goto(url);await ready(a);await bpage.goto(url);await ready(bpage);
  await a.click('#multiplayer');await a.fill('#rider-name','Autumn');await a.click('#create-room');await a.waitForFunction(()=>Redline.connected);
  const code=await a.evaluate(()=>Redline.room);assert.match(code,/^[A-F0-9]{6}$/);
  await bpage.click('[data-vehicle="surron"]');await bpage.click('[data-map="desert"]');await bpage.click('#multiplayer');await bpage.fill('#rider-name','Second rider');await bpage.fill('#room-input',code);await bpage.click('#join-room');
  await bpage.waitForFunction(()=>Redline.connected&&Redline.peers.length===1);await a.waitForFunction(()=>Redline.peers.length===1);
  assert.equal(await bpage.evaluate(()=>Redline.map),'coast');assert.equal(await bpage.evaluate(()=>Redline.vehicle),'surron');
  if(await bpage.evaluate(()=>Redline.paused))await bpage.click('#resume');
  await bpage.keyboard.down('KeyW');await bpage.waitForFunction(()=>Redline.state.speed>8);await bpage.keyboard.down('Space');await bpage.waitForFunction(()=>Redline.state.pitch>.5);
  await a.waitForFunction(()=>Redline.peers.some(p=>p.vehicle==='surron'&&p.speed>7&&p.pitch>.3));
  assert.equal((await a.evaluate(()=>Redline.peers))[0].name,'Second rider');await a.screenshot({path:output+'06-two-player-session.png'});
  await bpage.keyboard.up('KeyW');await bpage.keyboard.up('Space');await bpage.click('#pause');await bpage.click('#to-garage');await a.waitForFunction(()=>Redline.peers.length===0);
  await checkpoint('Two browser clients share a room, map, vehicle motion, wheelies, names, and departures');await ac.close();await bc.close();

  const offline=await browser.newPage();watch(offline);await offline.route(/^https?:/,r=>r.abort());await offline.goto(new URL('../ios/Redline/Web/index.html',import.meta.url).href);await ready(offline);await offline.click('#ride');assert(await offline.evaluate(()=>Redline.playing));await offline.close();
  await checkpoint('Bundled iOS web assets launch directly from disk without network access');
  assert.deepEqual(errors,[],'browser JavaScript exceptions');
  await writeFile(output+'browser-results.json',JSON.stringify({passed:true,checks:results,errors},null,2));
  console.log(`All ${results.length} browser scenarios passed.`);
}catch(error){await writeFile(output+'browser-results.json',JSON.stringify({passed:false,checks:results,errors,error:error.stack},null,2));throw error;}
finally{await browser.close();await game.close();}
