import test from 'node:test';
import assert from 'node:assert/strict';
import { WebSocket } from 'ws';
import { once } from 'node:events';
import { createGameServer } from '../server/server.mjs';
import { createState, snapshot } from '../src/core.mjs';
function inbox(ws){const queued=[],waiters=[];ws.on('message',b=>{const m=JSON.parse(b);const i=waiters.findIndex(w=>w.type===m.type);if(i>=0){const w=waiters.splice(i,1)[0];clearTimeout(w.timer);w.resolve(m);}else queued.push(m);});return type=>{const i=queued.findIndex(x=>x.type===type);if(i>=0)return Promise.resolve(queued.splice(i,1)[0]);return new Promise((resolve,reject)=>{const w={type,resolve,timer:setTimeout(()=>{const i=waiters.indexOf(w);if(i>=0)waiters.splice(i,1);reject(new Error(`Timeout waiting for ${type}`));},1500)};waiters.push(w);});};}
test('two real WebSocket clients join, exchange motion, keep maps isolated, and disconnect',async()=>{
  const game=createGameServer();await new Promise(r=>game.server.listen(0,'127.0.0.1',r));
  const sockets=[];async function client(){const ws=new WebSocket(`ws://127.0.0.1:${game.server.address().port}/multiplayer`),next=inbox(ws);sockets.push(ws);await once(ws,'open');return {ws,next,send:m=>ws.send(JSON.stringify(m))};}
  try{
    const a=await client();a.send({type:'create',map:'coast',name:'Autumn'});const welcome=await a.next('welcome');assert.match(welcome.room,/^[A-F0-9]{6}$/);
    const b=await client();b.send({type:'join',room:welcome.room,map:'desert',name:'Friend'});const joined=await b.next('welcome');assert.equal(joined.map,'coast');assert.equal(joined.peers[0].name,'Autumn');await a.next('peerJoin');
    const pose=snapshot(createState('coast','surron'));pose.speed=18;pose.pitch=.8;a.send({type:'state',state:pose,id:'spoofed'});const received=await b.next('state');assert.equal(received.id,welcome.id);assert.equal(received.state.speed,18);assert.equal(received.state.pitch,.8);assert.equal(received.state.name,'Autumn');
    a.send({type:'state',state:{...pose,map:'city'}});a.send({type:'state',state:{...pose,x:1e20}});a.send({type:'state',state:{...pose,x:25}});assert.equal((await b.next('state')).state.x,25);
    const c=await client();c.send({type:'create',map:'desert',name:'Isolated'});const other=await c.next('welcome');assert.notEqual(other.room,welcome.room);
    b.ws.close();assert.equal((await a.next('peerLeave')).id,joined.id);
    assert.equal(game.rooms.get(welcome.room).clients.size,1);
    const bad=await client();bad.send({type:'join',room:'XXXXXX'});assert.match((await bad.next('error')).message,/not found/);
    const response=await fetch(`http://127.0.0.1:${game.server.address().port}/`);assert.equal(response.status,200);assert.match(await response.text(),/REDLINE/);
  }finally{for(const s of sockets)s.terminate();await game.close();}
});
test('rooms enforce four-player capacity',async()=>{
  const game=createGameServer();await new Promise(r=>game.server.listen(0,'127.0.0.1',r));const sockets=[];
  try{let code;for(let i=0;i<5;i++){
    const ws=new WebSocket(`ws://127.0.0.1:${game.server.address().port}/multiplayer`),next=inbox(ws);sockets.push(ws);await once(ws,'open');ws.send(JSON.stringify(i?{type:'join',room:code,name:`R${i}`}:{type:'create',map:'city',name:'Host'}));
    const m=await next(i===4?'error':'welcome');if(!i)code=m.room;if(i===4)assert.match(m.message,/four riders/);
  }}finally{for(const s of sockets)s.terminate();await game.close();}
});
