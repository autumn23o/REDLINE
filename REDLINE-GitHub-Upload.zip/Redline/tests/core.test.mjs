import test from 'node:test';
import assert from 'node:assert/strict';
import { MAPS, VEHICLES, STEP, createState, resetState, step, snapshot, validSnapshot, surface, getScenery, getTrack, angleDelta, clamp, interpolateRemote } from '../src/core.mjs';
const drive=(s,seconds,input)=>{for(let t=0;t<seconds;t+=STEP)step(s,input,STEP);return s;};
for(const kind of Object.keys(VEHICLES)){
  test(`${kind}: throttle moves, braking stops, and speed stays bounded`,()=>{
    const s=createState('coast',kind),start={x:s.x,z:s.z};drive(s,1,{gas:1});
    assert(s.speed>8);assert(Math.hypot(s.x-start.x,s.z-start.z)>3);assert(s.speed<=VEHICLES[kind].max);
    drive(s,2,{brake:1});assert.equal(s.speed,0);const x=s.x,z=s.z;drive(s,1,{brake:1});assert.equal(s.x,x);assert.equal(s.z,z);
  });
  test(`${kind}: wheelie availability and brake recovery`,()=>{
    const s=createState('coast',kind);drive(s,1.4,{gas:1,wheelie:true});
    if(kind==='kart'){assert.equal(s.pitch,0);assert.equal(s.wheelieSeconds,0);}else{assert(s.pitch>.6);assert(s.wheelieSeconds>.3);assert(s.score>5);drive(s,.6,{brake:1,wheelie:true});assert(s.pitch<.02);}
  });
}
test('steering changes direction only while moving and wheelies reduce steering authority',()=>{
  const normal=createState(),wheelie=createState();const initial=normal.heading;drive(normal,1,{steer:1});assert.equal(normal.heading,initial);
  normal.speed=20;wheelie.speed=20;wheelie.pitch=.9;step(normal,{gas:1,steer:1});step(wheelie,{gas:1,steer:1,wheelie:true});
  assert(normal.heading-initial>wheelie.heading-initial);assert(wheelie.heading>initial);
});
test('checkpoint order prevents a finish-line shortcut and a complete ordered circuit counts once',()=>{
  const s=createState();s.x=0;s.z=95;step(s,{});assert.equal(s.lap,0);assert.equal(s.nextCheckpoint,1);
  const points=MAPS.coast.points;s.x=points[4][0];s.z=points[4][1];step(s,{});assert.equal(s.nextCheckpoint,1);
  for(let i=1;i<=points.length;i++){const cp=points[i%points.length];s.x=cp[0];s.z=cp[1];s.lapElapsed+=2;step(s,{});}
  assert.equal(s.lap,1);assert(s.lastLap>10);assert.equal(s.bestLap,s.lastLap);assert.equal(s.nextCheckpoint,1);assert(s.score>=500);
});
for(const map of Object.keys(MAPS)){
  test(`${map}: full driving lap follows the road and finishes`,()=>{
    const s=createState(map,'surron',1),track=getTrack(map);let time=0;
    while(s.lap<1&&time<150){
      let nearest=0,dist=Infinity;for(let i=0;i<track.length;i++){const d=Math.hypot(s.x-track[i].x,s.z-track[i].z);if(d<dist){dist=d;nearest=i;}}
      const target=track[(nearest+3)%track.length],desired=Math.atan2(target.x-s.x,target.z-s.z);
      step(s,{gas:s.speed<12?0.7:0,brake:s.speed>15?.25:0,steer:clamp(angleDelta(s.heading,desired)*2.2,-1,1)});time+=STEP;
    }
    assert.equal(s.lap,1,`no complete lap in ${time}s, checkpoint ${s.nextCheckpoint}`);assert(s.lastLap>30);
  });
  test(`${map}: ramps launch a moving bike and return it to ground`,()=>{
    const r=MAPS[map].ramps[0],s=createState(map,'surron');s.x=r.x-Math.sin(r.heading)*(r.length/2+1);s.z=r.z-Math.cos(r.heading)*(r.length/2+1);s.heading=r.heading;s.speed=20;
    let airborne=false,maxY=0;for(let i=0;i<240;i++){step(s,{gas:.6});airborne ||= !s.grounded;maxY=Math.max(maxY,s.y);}
    assert(airborne);assert(maxY>r.height);assert.equal(s.grounded,true);assert.equal(s.y,0);assert(s.score>0);
  });
}
test('collision repels a vehicle and reduces speed',()=>{
  const s=createState('city'),o=getScenery('city')[0];s.x=o.x-o.w/2-.75;s.z=o.z;s.heading=Math.PI/2;s.speed=24;
  step(s,{gas:1});assert(s.crashed>0);assert(s.speed<6);assert(s.x<=o.x-o.w/2-.699);
});
test('boundary and reset recover a rider without losing best lap or earned score',()=>{
  const s=createState();s.x=224.9;s.z=0;s.heading=Math.PI/2;s.speed=50;s.score=42;s.bestLap=70;step(s,{gas:1});assert(s.x<=225);assert(s.crashed>0);
  resetState(s);assert.equal(s.speed,0);assert.equal(s.score,42);assert.equal(s.bestLap,70);assert.equal(s.nextCheckpoint,1);
});
test('10,000 random inputs remain finite and below vehicle limits',()=>{
  let n=42;const rand=()=>((n=(Math.imul(n,1664525)+1013904223)>>>0)/2**32);
  for(const kind of Object.keys(VEHICLES)){
    const s=createState('desert',kind);for(let i=0;i<10000;i++)step(s,{gas:rand(),brake:rand()<.05?1:0,steer:(rand()-.5)*2,wheelie:rand()>.4});
    for(const k of ['x','z','speed','y','vy','heading','score'])assert(Number.isFinite(s[k]),k);assert(s.speed<=VEHICLES[kind].max);assert(s.y>=0);
  }
});
test('wire schema rejects map mismatch, malformed data, prototype keys, and nonfinite numbers',()=>{
  const good=snapshot(createState());assert(validSnapshot(good,'coast'));
  for(const bad of [null,{}, {...good,map:'city'},{...good,vehicle:'__proto__'},{...good,x:NaN},{...good,y:-1},{...good,speed:Infinity},{...good,name:'x'.repeat(21)},{...good,checkpoint:99}])assert.equal(validSnapshot(bad,'coast'),false);
});
test('remote headings interpolate across 2π without spinning around',()=>{
  const s={x:0,z:0,y:0,speed:0,pitch:0,lean:0,heading:Math.PI-.01},target={...s,x:10,heading:-Math.PI+.01};
  interpolateRemote(s,target,.05);assert(s.x>0&&s.x<10);assert(Math.abs(angleDelta(Math.PI-.01,s.heading))<.02);
});
