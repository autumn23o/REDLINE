# Validation — 27 October 2026

This is a playable prototype with a source-level iOS integration. A clean browser run does not prove that an iOS app compiles, signs, performs well on hardware, or completes Game Center matchmaking.

## Verified here

- **21 automated simulation/relay tests:** acceleration and braking for all vehicles; bike wheelies and kart restrictions; wheelie steering reduction; checkpoint ordering; a driven full lap on each map; ramp launch and landing on each map; object collision; boundary recovery; reset; 10,000 randomized inputs per vehicle; malformed packet rejection; angle interpolation; real WebSocket room joining, state replication, isolation, departure, and four-player capacity.
- **Desktop Chromium:** garage and help, all vehicles/maps, throttle, braking, wheelies, pause/resume/reset, and actual WebGL rendering.
- **Mobile-sized Chromium, 852 × 393:** touch controls in bounds, map choices accessible, simultaneous gas + wheelie, touch cancellation, and brake recovery.
- **Two independent browser contexts:** actual relay connection, map agreement, differing vehicle selections, remote movement/wheelie replication, display names, and departure removal.
- **Offline bundled launch:** the same local HTML/JavaScript assets used by iOS launch without external network requests.
- Info.plist, entitlements, privacy manifest, asset catalog JSON, and shared Xcode scheme parse successfully.

The reproducible browser suite writes `test-results/browser-results.json` and local inspection images when run. Inspection screenshots are not shipped as game assets.

## Still required on Apple tooling / hardware

- Compile and run the Swift target in Xcode or the supplied macOS CI workflow.
- Sign a build with an app identifier and provisioning profile that allow Game Center.
- Test authentication, invitations, map negotiation, disconnects, and background/foreground behavior on two real iPhones with separate Game Center accounts.
- Verify WKWebView/WebGL behavior, safe-area insets, audio interruption behavior, frame rate, memory use, and thermal performance on target devices. No native-device frame-rate claim is made.
- Review distribution metadata and privacy declarations against the final shipped app and any future analytics or SDK additions before submission.

No native compilation, device installation, Apple account configuration, IPA signing, TestFlight upload, or App Store publication was performed here. The GitHub workflow is provided but has not been executed in a repository.

## Deliberate prototype limits

Arcade physics and procedural art; casual client-authoritative multiplayer; individual lap timers; no player-to-player collisions; no synchronized competitive race start; no reverse gear; no anti-cheat or public matchmaking backend for the browser build; no cross-play between Game Center and browser rooms. Local best laps are stored on the device. No external artwork, Surron branding, or licensed motorcycle models are used.
