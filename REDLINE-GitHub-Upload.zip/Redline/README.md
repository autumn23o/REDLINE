# REDLINE — Street Sessions

A playable 3D arcade riding prototype for iPhone and iPad, with an offline game bundled inside a native Swift/UIKit app. The same game also runs in a desktop browser for development and multiplayer testing.

**Delivery status:** gameplay and browser multiplayer have been tested in this workspace. The native iOS source is included, but no Apple compiler or signing identity was available here. This download is an Xcode project, not a signed or device-verified IPA. See [VALIDATION.md](VALIDATION.md) for exact coverage and remaining checks.

## What is playable

- **R / 900:** sport motorcycle with higher road speed and wheelies.
- **VOLT / X:** Surron-style electric dirt bike with quicker acceleration, stronger off-road grip, and wheelies. It is an original stylized model, not an official Surron asset or licensed product.
- **KART / 125:** four-wheel go-kart with tighter steering. Wheelies are intentionally unavailable on the kart.
- **Pacific Run:** coastal highway, palm trees, ocean, and a stunt ramp.
- **Midnight Grid:** city circuit with lit buildings and a central jump.
- **Red Rock Rally:** winding desert dirt track and two jump ramps.
- Touch throttle, brake, left/right steering, wheelie, reset, camera toggle, and pause.
- Chase camera, vehicle lean, animated wheels, ramps, collisions, off-road slowing, minimap, ordered lap checkpoints, persistent best laps, wheelie/airtime scoring, and optional synthesized engine audio.
- **2–4-player Game Center integration on iOS:** invitations, matchmaking, same-map negotiation, 15 Hz motion updates, remote interpolation, scores, and disconnect handling.
- **2–4-player browser multiplayer:** a working Node WebSocket relay with private room codes. This is a separate transport from Game Center; there is no iOS-to-browser cross-play.

All vehicles and maps are unlocked. Multiplayer is a casual shared free-ride session with individual lap timers and a session score board. There is no synchronized race countdown, ranked result, vehicle-to-vehicle collision, account system, monetization, voice chat, or persistent online progression.

## Play the included preview

On a computer, open `Play-REDLINE.html` in a WebGL-capable browser for offline solo play. It contains the game and its assets in a single file. Downloaded HTML may open as a document preview in iPhone Files; use the native app or the server method below to play on iPhone.

For browser multiplayer, install Node.js 20 or newer, then run from this folder:

```sh
npm ci
npm start
```

Open `http://localhost:8080`. Choose **Ride with friends → Create room**. A second browser can join with the displayed six-character code. For two phones on the same Wi-Fi, open `http://YOUR-COMPUTER-LAN-IP:8080` on both; the computer must allow incoming traffic on port 8080. The relay listens on all interfaces by default. To restrict it locally, start with `HOST=127.0.0.1 npm start`.

The local server is not publicly hosted. Internet browser multiplayer requires deploying it behind an HTTPS/WSS reverse proxy. It uses client-authoritative movement and is intended for private casual sessions, not competitive anti-cheat. iOS Game Center multiplayer does not use this relay.

## Build and install on iPhone

1. On a Mac with Xcode 16 or newer, open `ios/Redline.xcodeproj` and select the **Redline** scheme. Bundled assets are already present; Node is only needed if you change game code.
2. Select the Redline target → **Signing & Capabilities**. Set your development team and change `com.yourstudio.redline` to an App ID you own. Keep the **Game Center** capability enabled for multiplayer.
3. Configure that same App ID and app for Game Center in your Apple developer account/App Store Connect. Install the same app identity on both test devices and use separate Game Center accounts.
4. Select your connected iPhone, allow Developer Mode if requested by the phone, and run the app. The deployment target is iOS 16.0; the scene lifecycle and landscape layouts support modern iOS versions.
5. In the game, choose a map and vehicle, then **Ride with friends → Find riders**. Matchmaking groups automatched players by map. When processing direct invitations, a deterministic peer coordinates the final shared map before gameplay begins.

For solo testing with signing that cannot use Game Center, remove the Game Center capability and its entitlement from your local copy. The offline game remains available, but Game Center matchmaking will not work with that build. Re-signing an unsigned IPA with a profile lacking the required Game Center entitlement does not enable multiplayer.

For distribution, archive with your own signing and use TestFlight or an appropriate signed export. Apple account setup, certificates, profiles, app registration, and distribution are not included in this project.

## Build on GitHub's macOS runners

The included `.github/workflows/ios-build.yml` is ready to run after the project is committed to your own repository. It has **not** been uploaded or run on GitHub as part of this delivery.

1. Commit the complete project, including the `.github` directory, `ios` folder, and lockfile, to a repository.
2. In **Actions**, run **Build REDLINE for iOS** (or push to `main` / `master`).
3. The workflow runs gameplay and browser tests, then compiles both simulator and iPhone builds on a Mac runner.
4. If all jobs succeed, download **Redline-unsigned-IPA** or **Redline-iOS-Simulator** from the workflow artifacts.

The IPA artifact is **unsigned**. It is a build output, not an immediately installable App Store/TestFlight release. A valid signing/export process and a Game Center-enabled app identity are still required for real iPhone multiplayer.

## Controls

| Action | iPhone | Keyboard |
|---|---|---|
| Accelerate | Hold GAS | W / ↑ |
| Brake | Hold BRAKE | S / ↓ |
| Steer | Hold left/right | A / D or ← / → |
| Wheelie | Hold GAS + WHEELIE on either bike | W + Space |
| Lower the front wheel | Release wheelie or brake | Release Space or press S |
| Reset to starting line | ↺ | R |
| Change chase camera | CAM | C |
| Pause / resume | Pause button | Escape |

Follow the next lime checkpoint on the minimap. Every checkpoint must be reached in order before a lap counts. A completed lap earns 500 points; bike wheelies and landed jumps earn extra points. Braking stops the vehicle; it does not engage reverse. Use reset if you become stuck.

## Development

```sh
npm ci
npm test
npm run build
npx playwright install chromium
npm run test:browser
```

`npm run build` bundles Three.js and the game into `web/game.js`, copies local assets into `ios/Redline/Web`, and refreshes `Play-REDLINE.html`. The iOS app never needs a CDN or remote game server for solo play.

| Path | Purpose |
|---|---|
| `src/core.mjs` | Deterministic simulation, maps, collisions, lap rules, packet validation |
| `src/world.mjs` | Procedural 3D models and scenery, batching, lighting |
| `src/game.mjs` | Menus, controls, cameras, audio, HUD, game loop |
| `src/network.mjs` | Shared Game Center/browser transport adapter |
| `server/server.mjs` | Browser multiplayer relay and static server |
| `ios/Redline` | UIKit/scene lifecycle, WebKit wrapper, GameKit, assets |
| `tests` | Simulation, real WebSocket, and browser tests |
| `scripts/generate_xcode.py` | Recreate the checked-in Xcode project without XcodeGen |

The art is original procedural geometry. Three.js is distributed under its MIT license in `THIRD_PARTY_NOTICES.txt`. First-party code is licensed under `LICENSE`.

## Apple integration references

- [Game Center setup](https://developer.apple.com/documentation/gamekit/initializing-and-configuring-game-center)
- [Player authentication](https://developer.apple.com/documentation/gamekit/authenticating-a-player)
- [Real-time data exchange](https://developer.apple.com/documentation/gamekit/exchanging-data-between-players-in-real-time-games)
- [Scene lifecycle](https://developer.apple.com/documentation/uikit/transitioning-to-the-uikit-scene-based-life-cycle)
