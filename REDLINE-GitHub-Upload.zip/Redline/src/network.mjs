import { validSnapshot, MAPS } from './core.mjs';
export class Network {
  constructor(){
    this.id=null;this.room=null;this.map=null;this.peers=new Map();this.listeners={};this.socket=null;this.connected=false;this.native=Boolean(window.webkit?.messageHandlers?.redline);
    window.RedlineNative={receive:message=>this.receiveNative(message)};
    if(this.native)this.postNative({action:'ready'});
  }
  on(event,fn){(this.listeners[event]??=[]).push(fn);return this;}
  emit(event,payload){for(const fn of this.listeners[event]||[])fn(payload);}
  postNative(message){window.webkit?.messageHandlers?.redline?.postMessage(message);}
  receiveNative(message){
    if(!message||typeof message!=='object')return;
    if(message.type==='connected'&&Object.hasOwn(MAPS,message.map)){
      this.map=message.map;this.id=message.id;this.room='GAME CENTER';this.connected=true;this.peers.clear();
      for(const p of message.peers||[])this.peers.set(p.id,{name:p.name});this.emit('connected',message);
    }else if(message.type==='state'&&this.connected&&message.id!==this.id&&this.peers.has(message.id)&&validSnapshot(message.state,this.map)){
      this.emit('state',{id:message.id,state:message.state});
    }else if(message.type==='peerJoin'){
      this.peers.set(message.id,{name:message.name});this.emit('peerJoin',message);
    }else if(message.type==='peerLeave'){
      this.peers.delete(message.id);this.emit('peerLeave',message);
    }else if(message.type==='disconnected'){this.clear();this.emit('disconnected',message);}
    else if(message.type==='error')this.emit('error',message.message||'Multiplayer is unavailable.');
    else if(message.type==='paused')this.emit('paused',message);
    else if(message.type==='auth')this.emit('auth',message);
  }
  match(map){this.map=map;this.postNative({action:'match',map});}
  connect({map='coast',room='',name='Rider',url}={}){
    this.leave();this.map=map;
    return new Promise((resolve,reject)=>{
      let settled=false;
      const socket=new WebSocket(url||`${location.protocol==='https:'?'wss:':'ws:'}//${location.host}/multiplayer`);this.socket=socket;
      const timer=setTimeout(()=>fail('The multiplayer server did not respond.'),10000);
      const fail=message=>{if(!settled){settled=true;clearTimeout(timer);reject(new Error(message));}socket.close();};
      socket.onopen=()=>socket.send(JSON.stringify({type:room?'join':'create',map,room:room.trim().toUpperCase(),name:String(name).trim().slice(0,20)||'Rider'}));
      socket.onmessage=e=>{
        let m;try{m=JSON.parse(e.data);}catch{return;}
        if(m.type==='welcome'&&Object.hasOwn(MAPS,m.map)){
          this.id=m.id;this.map=m.map;this.room=m.room;this.connected=true;this.peers.clear();
          for(const p of m.peers)this.peers.set(p.id,{name:p.name});clearTimeout(timer);settled=true;resolve(m);this.emit('connected',m);
        }else if(m.type==='state'&&this.connected&&m.id!==this.id&&this.peers.has(m.id)&&validSnapshot(m.state,this.map))this.emit('state',m);
        else if(m.type==='peerJoin'){this.peers.set(m.id,{name:m.name});this.emit('peerJoin',m);}
        else if(m.type==='peerLeave'){this.peers.delete(m.id);this.emit('peerLeave',m);}
        else if(m.type==='error'){if(!settled)fail(m.message);else this.emit('error',m.message);}
      };
      socket.onerror=()=>fail('Could not reach multiplayer. Open this game from the included server.');
      socket.onclose=()=>{clearTimeout(timer);if(!settled){settled=true;reject(new Error('Connection closed before joining.'));}if(this.socket===socket){const was=this.connected;this.clear();this.socket=null;if(was)this.emit('disconnected',{message:'Connection lost. Your solo ride can continue.'});}};
    });
  }
  send(state){
    if(!this.connected||!validSnapshot(state,this.map))return;
    if(this.native)this.postNative({action:'state',state});
    else if(this.socket?.readyState===WebSocket.OPEN)this.socket.send(JSON.stringify({type:'state',state}));
  }
  clear(){this.connected=false;this.id=null;this.room=null;this.peers.clear();}
  leave(){if(this.native&&this.connected)this.postNative({action:'leave'});const socket=this.socket;this.socket=null;socket?.close();this.clear();}
}
