// Pure simulation shared by the renderer, relay validation, and tests.
export const VERSION = 1;
export const STEP = 1 / 60;
export const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
export const lerp = (a, b, t) => a + (b - a) * t;
export const angleDelta = (a, b) => Math.atan2(Math.sin(b - a), Math.cos(b - a));
export const VEHICLES = {
  moto: { name: 'R / 900', type: 'Sport motorcycle', color: '#c6ff38', max: 53, accel: 15, brake: 27, turn: 0.97, wheelie: 0.90, grip: 1, wheelbase: 1.62 },
  surron: { name: 'VOLT / X', type: 'Surron-style electric dirt bike', color: '#69e5ff', max: 34, accel: 17, brake: 24, turn: 1.20, wheelie: 1.05, grip: 1.45, wheelbase: 1.38 },
  kart: { name: 'KART / 125', type: 'Racing go-kart', color: '#ff825c', max: 39, accel: 12, brake: 29, turn: 1.45, wheelie: 0, grip: 0.85, wheelbase: 1.28 }
};
export const MAPS = {
  coast: { name: 'Pacific Run', subtitle: 'Ocean air. Endless asphalt.', biome: 'coast', length: '2.1', color: '#c6ff38', width: 14, bounds: 225,
    points: [[0,95],[85,90],[128,34],[110,-45],[52,-98],[-42,-110],[-115,-56],[-125,29],[-65,94]],
    ramps: [{x:32,z:48,heading:Math.PI/2,width:7,length:12,height:3.6}],
    sky: 0xc0e0e2, ground: 0xa4b59a, fog: 0xc0e0e2 },
  city: { name: 'Midnight Grid', subtitle: 'Neon lights. Tight corners.', biome: 'city', length: '1.8', color: '#a6a5ff', width: 15, bounds: 220,
    points: [[0,90],[95,90],[118,57],[118,-70],[82,-100],[-75,-100],[-112,-65],[-112,60],[-77,90]],
    ramps: [{x:0,z:3,heading:0,width:8,length:14,height:4}],
    sky: 0x18263c, ground: 0x293740, fog: 0x22344c },
  desert: { name: 'Red Rock Rally', subtitle: 'Dust trails. Big air.', biome: 'desert', length: '2.2', color: '#ffb17a', width: 13, bounds: 230,
    points: [[0,103],[74,84],[132,22],[99,-42],[120,-96],[34,-128],[-58,-87],[-130,-110],[-148,-27],[-95,36],[-72,99]],
    ramps: [{x:10,z:43,heading:Math.PI/2,width:9,length:15,height:4.4},{x:-42,z:-13,heading:Math.PI,width:9,length:13,height:3.8}],
    sky: 0xf4ceae, ground: 0xc99568, fog: 0xe7b892 }
};
export function seeded(seed) { let n=seed>>>0; return () => { n=(Math.imul(n,1664525)+1013904223)>>>0; return n/4294967296; }; }
export function trackPoints(map, steps=20) {
  const p=typeof map==='string'?MAPS[map].points:map.points, out=[];
  for(let i=0;i<p.length;i++) for(let j=0;j<steps;j++) {
    const t=j/steps, t2=t*t, t3=t2*t;
    const a=p[(i+p.length-1)%p.length], b=p[i], c=p[(i+1)%p.length], d=p[(i+2)%p.length];
    const at=k=>0.5*(2*b[k]+(-a[k]+c[k])*t+(2*a[k]-5*b[k]+4*c[k]-d[k])*t2+(-a[k]+3*b[k]-3*c[k]+d[k])*t3);
    out.push({x:at(0),z:at(1)});
  }
  return out;
}
const tracks=Object.fromEntries(Object.keys(MAPS).map(k=>[k,trackPoints(k)]));
export const getTrack = k => tracks[k];
export function segmentDistance(x,z,a,b) {
  const dx=b.x-a.x,dz=b.z-a.z, t=clamp(((x-a.x)*dx+(z-a.z)*dz)/(dx*dx+dz*dz||1),0,1);
  return Math.hypot(x-a.x-dx*t,z-a.z-dz*t);
}
export function roadDistance(map,x,z) {
  const t=tracks[map]; let d=Infinity;
  for(let i=0;i<t.length;i++) d=Math.min(d,segmentDistance(x,z,t[i],t[(i+1)%t.length]));
  return d;
}
export function scenery(map) {
  const r=seeded({coast:431,city:867,desert:297}[map]), items=[];
  if(map==='coast')items.push({kind:'pavilion',x:-18,z:24,w:14,d:7,h:3.2,r:8,tone:0});
  if(map==='city') {
    for(let x=-180;x<=180;x+=32) for(let z=-180;z<=180;z+=32) {
      const px=x+(r()-.5)*4,pz=z+(r()-.5)*4;
      if(roadDistance(map,px,pz)>25 && Math.hypot(px,pz)>28) items.push({kind:'building',x:px,z:pz,r:10,w:15+r()*7,h:12+r()*55,d:15+r()*7,tone:r()});
    }
  } else {
    for(let i=0;i<190;i++) {
      const x=(r()-.5)*410,z=(r()-.5)*410;
      if(roadDistance(map,x,z)<14 || (map==='coast'&&x>150) || Math.hypot(x,z)<54) continue;
      const rock=map==='desert'?r()<.55:r()<.15;
      items.push({kind:rock?'rock':map==='desert'?'cactus':'palm',x,z,r:rock?2.8+r()*4:0.65,h:rock?3+r()*8:6+r()*6,tone:r()});
    }
  }
  return items;
}
const worlds=Object.fromEntries(Object.keys(MAPS).map(k=>[k,scenery(k)]));
export const getScenery=k=>worlds[k];
export function surface(map,x,z) {
  for(const r of MAPS[map].ramps) {
    const dx=x-r.x,dz=z-r.z,u=dx*Math.cos(r.heading)-dz*Math.sin(r.heading), v=dx*Math.sin(r.heading)+dz*Math.cos(r.heading);
    if(Math.abs(u)<r.width/2 && v>=-r.length/2 && v<=r.length/2) return {height:(v/r.length+.5)*r.height,slope:r.height/r.length,heading:r.heading};
  }
  return {height:0,slope:0,heading:0};
}
export function createState(map='coast', vehicle='moto',slot=0) {
  const t=tracks[map],heading=Math.atan2(t[1].x-t[0].x,t[1].z-t[0].z),side=(slot%4-1.5)*2;
  return {map,vehicle,x:t[0].x+Math.cos(heading)*side,z:t[0].z-Math.sin(heading)*side,heading,speed:0,y:0,vy:0,pitch:0,lean:0,grounded:true,
    wheelTravel:0,score:0,wheelieSeconds:0,wheelieRun:0,airTime:0,totalDistance:0,lap:0,nextCheckpoint:1,lapElapsed:0,lastLap:0,bestLap:0,crashed:0,checkpointFlash:0};
}
export function resetState(s) {
  const fresh=createState(s.map,s.vehicle); Object.assign(s,fresh,{score:s.score,bestLap:s.bestLap}); return s;
}
export function step(s,input,dt=STEP) {
  dt=clamp(dt,0,0.05); if(!dt)return s;
  const v=VEHICLES[s.vehicle], map=MAPS[s.map];
  const gas=clamp(Number(input.gas)||0,0,1),brake=clamp(Number(input.brake)||0,0,1),steer=clamp(Number(input.steer)||0,-1,1);
  const oldX=s.x,oldZ=s.z,wasGrounded=s.grounded;
  s.crashed=Math.max(0,s.crashed-dt); s.checkpointFlash=Math.max(0,s.checkpointFlash-dt);
  const offroad=roadDistance(s.map,s.x,s.z)>map.width/2;
  const drag=0.24+s.speed*s.speed*0.0027+(offroad?3.9/v.grip:0);
  const effectiveGas=s.crashed>0?0:gas;
  s.speed=clamp(s.speed+(effectiveGas*v.accel*(1-s.speed/(v.max*1.12))-brake*v.brake-drag)*dt,0,v.max*(offroad?(s.vehicle==='surron'?.92:.65):1));
  const wheelieTarget=input.wheelie&&v.wheelie&&s.speed>3&&gas>0.1&&brake<0.1&&wasGrounded?v.wheelie:0;
  s.pitch=lerp(s.pitch,wheelieTarget,1-Math.exp(-dt*(brake>0?12:5)));
  const steerLimit=v.turn/(1+s.speed/30)*(s.pitch>.25?.54:1);
  s.heading+=steer*steerLimit*clamp(s.speed/5,0,1)*dt;
  s.lean=lerp(s.lean,-steer*clamp(s.speed/24,0,1)*(s.vehicle==='kart'?.08:.42),1-Math.exp(-dt*8));
  s.x+=Math.sin(s.heading)*s.speed*dt; s.z+=Math.cos(s.heading)*s.speed*dt;
  let hit=false;
  if(Math.abs(s.x)>map.bounds||Math.abs(s.z)>map.bounds) {s.x=clamp(s.x,-map.bounds,map.bounds);s.z=clamp(s.z,-map.bounds,map.bounds);hit=true;}
  for(const o of worlds[s.map]) {
    if(s.y>o.h)continue;
    if(o.kind==='building'||o.kind==='pavilion'){
      const radius=s.vehicle==='kart'?1.2:.7,minX=o.x-o.w/2,maxX=o.x+o.w/2,minZ=o.z-o.d/2,maxZ=o.z+o.d/2;
      const cx=clamp(s.x,minX,maxX),cz=clamp(s.z,minZ,maxZ),dx=s.x-cx,dz=s.z-cz,d=Math.hypot(dx,dz);
      if(d>0&&d<radius){s.x=cx+dx/d*radius;s.z=cz+dz/d*radius;hit=true;}
      else if(d===0){
        const faces=[{d:s.x-minX,x:minX-radius,z:s.z},{d:maxX-s.x,x:maxX+radius,z:s.z},{d:s.z-minZ,x:s.x,z:minZ-radius},{d:maxZ-s.z,x:s.x,z:maxZ+radius}].sort((a,b)=>a.d-b.d);
        s.x=faces[0].x;s.z=faces[0].z;hit=true;
      }
      continue;
    }
    const d=Math.hypot(s.x-o.x,s.z-o.z),radius=o.r+(s.vehicle==='kart'?1.2:.7);
    if(d<radius) {const nx=d>.01?(s.x-o.x)/d:1,nz=d>.01?(s.z-o.z)/d:0;s.x=o.x+nx*radius;s.z=o.z+nz*radius;hit=true;}
  }
  if(hit) {s.speed*=.18;s.crashed=.35;s.pitch=0;s.wheelieRun=0;}
  const ground=surface(s.map,s.x,s.z), previous=surface(s.map,oldX,oldZ);
  if(wasGrounded&&previous.height>ground.height+.16&&s.speed>4) {s.grounded=false;s.vy=Math.max(1.3,s.speed*previous.slope*Math.cos(s.heading-previous.heading));}
  if(s.grounded){s.y=ground.height;s.vy=0;} else {
    s.vy-=14*dt;s.y+=s.vy*dt;s.airTime+=dt;
    if(s.y<=ground.height) {s.y=ground.height;s.vy=0;s.grounded=true;if(s.airTime>.3)s.score+=Math.floor(s.airTime*120);s.airTime=0;}
  }
  if(s.pitch>.35&&s.grounded&&!hit) {s.wheelieSeconds+=dt;s.wheelieRun+=dt;s.score+=dt*(25+Math.min(s.wheelieRun,5)*10);} else s.wheelieRun=0;
  s.wheelTravel+=s.speed*dt;s.totalDistance+=s.speed*dt;s.lapElapsed+=dt;
  const cp=map.points[s.nextCheckpoint];
  if(segmentDistance(cp[0],cp[1],{x:oldX,z:oldZ},{x:s.x,z:s.z})<map.width*.86) {
    if(s.nextCheckpoint===0){s.lap++;s.lastLap=s.lapElapsed;s.bestLap=s.bestLap?Math.min(s.bestLap,s.lastLap):s.lastLap;s.lapElapsed=0;s.score+=500;}
    s.nextCheckpoint=(s.nextCheckpoint+1)%map.points.length;s.checkpointFlash=.65;
  }
  return s;
}
export function snapshot(s, name='Rider') {
  return {v:VERSION,map:s.map,vehicle:s.vehicle,name:String(name).slice(0,20),x:s.x,z:s.z,y:s.y,heading:s.heading,speed:s.speed,pitch:s.pitch,lean:s.lean,score:Math.floor(s.score),lap:s.lap,checkpoint:s.nextCheckpoint};
}
export function validSnapshot(p,map) {
  if(!p||p.v!==VERSION||!Object.hasOwn(MAPS,p.map)||p.map!==map||!Object.hasOwn(VEHICLES,p.vehicle))return false;
  for(const k of ['x','z','y','heading','speed','pitch','lean','score','lap','checkpoint'])if(typeof p[k]!=='number'||!Number.isFinite(p[k]))return false;
  return Math.abs(p.x)<=250&&Math.abs(p.z)<=250&&p.y>=0&&p.y<=80&&p.speed>=0&&p.speed<=60&&Math.abs(p.pitch)<=1.5&&Math.abs(p.lean)<=1&&p.score>=0&&p.score<1e9&&Number.isInteger(p.lap)&&p.lap>=0&&p.lap<100000&&Number.isInteger(p.checkpoint)&&p.checkpoint>=0&&p.checkpoint<MAPS[map].points.length&&typeof p.name==='string'&&p.name.length<=20;
}
export function interpolateRemote(current,target,dt) {
  const t=1-Math.exp(-dt*12);
  for(const k of ['x','z','y','speed','pitch','lean']) current[k]=lerp(current[k],target[k],t);
  current.heading+=angleDelta(current.heading,target.heading)*t;
  return current;
}
export function formatTime(t) {return `${Math.floor(t/60)}:${(t%60).toFixed(2).padStart(5,'0')}`;}
