import { MAPS, VEHICLES, STEP, createState, resetState, step, snapshot, interpolateRemote, formatTime, clamp } from './core.mjs';
import { T, makeRenderer, makeWorld, disposeWorld, makeVehicle, poseVehicle } from './world.mjs';
import { Network } from './network.mjs';

const $=id=>document.getElementById(id),home=$('home'),hud=$('hud');
let selectedMap='coast',selectedVehicle='moto',playing=false,paused=false,world,vehicle,state,followMode=0,last=0,accumulator=0,sendClock=0,hudClock=0,toastTimer,menuMode='';
let bests={};try{bests=JSON.parse(localStorage.getItem('redline-bests')||'{}');}catch{}
const remote=new Map(),keys=new Set(),held=new Map(),net=new Network();
let gfx;
try{gfx=makeRenderer($('world'));}catch(error){$('loading').innerHTML='<h2>3D graphics are unavailable.</h2><p>Enable WebGL or try a newer browser, then reopen REDLINE.</p>';throw error;}
const {renderer,scene,camera,sun,ambient}=gfx;
const cameraTarget=new T.Vector3(),lookTarget=new T.Vector3();
const checkpointHalo=new T.Mesh(new T.TorusGeometry(2.2,.09,6,36),new T.MeshBasicMaterial({color:0xc6ff38,transparent:true,opacity:.8}));checkpointHalo.rotation.x=Math.PI/2;scene.add(checkpointHalo);

function toast(message,time=3500){$('toast').textContent=message;$('toast').classList.remove('hidden');clearTimeout(toastTimer);toastTimer=setTimeout(()=>$('toast').classList.add('hidden'),time);}
function saveBest(){try{localStorage.setItem('redline-bests',JSON.stringify(bests));}catch{}}
function discardVehicle(v){scene.remove(v);v.userData.shadow?.material.dispose();}
function clearRemote(){for(const p of remote.values())discardVehicle(p.model);remote.clear();$('roster').replaceChildren();}
function loadMap(key){
  if(world){scene.remove(world.root);disposeWorld(world);}selectedMap=key;world=makeWorld(key);scene.add(world.root);
  const m=MAPS[key];scene.background=new T.Color(m.sky);scene.fog=new T.Fog(m.fog,key==='city'?90:145,470);
  ambient.intensity=key==='city'?1.6:2.3;sun.intensity=key==='city'?1.6:3.1;renderer.toneMappingExposure=key==='city'?1.1:1.18;
  document.querySelectorAll('[data-map]').forEach(el=>{const selected=el.dataset.map===key;el.classList.toggle('selected',selected);el.setAttribute('aria-pressed',selected);});
  $('map-caption').textContent=m.subtitle;$('ride-map').textContent=m.name.toUpperCase();
  changeVehicle(selectedVehicle);
}
function changeVehicle(key){
  selectedVehicle=key;if(vehicle)discardVehicle(vehicle);vehicle=makeVehicle(key);scene.add(vehicle);
  state=createState(selectedMap,key);state.bestLap=Number(bests[`${selectedMap}/${key}`])||0;
  document.querySelectorAll('[data-vehicle]').forEach(el=>{const selected=el.dataset.vehicle===key;el.classList.toggle('selected',selected);el.setAttribute('aria-pressed',selected);});
  $('vehicle-type').textContent=VEHICLES[key].type.toUpperCase();$('vehicle-title').textContent=VEHICLES[key].name;
  $('wheelie').disabled=key==='kart';$('wheelie').setAttribute('aria-label',key==='kart'?'Wheelies are available on bikes':'Hold for wheelie');
  snapCamera();
}
function snapCamera(){const h=state.heading;camera.position.set(state.x-8*Math.sin(h)+6*Math.cos(h),state.y+4.2,state.z-8*Math.cos(h)-6*Math.sin(h));camera.lookAt(state.x,1,state.z);}
function startRide(){
  closeModal();releaseControls();playing=true;paused=false;home.classList.add('hidden');hud.classList.remove('hidden');document.body.classList.add('playing');
  state=createState(selectedMap,selectedVehicle,net.id?hash(net.id)%4:1);state.bestLap=Number(bests[`${selectedMap}/${selectedVehicle}`])||0;
  accumulator=0;snapCamera();audio.ensure();updateConnection();
  if(!net.connected)toast(selectedVehicle==='kart'?'Follow every lime checkpoint. Complete a lap for 500 points.':'Hold GAS + WHEELIE to lift. Brake to bring it down.',3200);
}
function hash(text){return [...text].reduce((a,c)=>((a*31+c.charCodeAt(0))>>>0),0);}
function garage(){net.leave();clearRemote();playing=false;paused=false;releaseControls();closeModal();hud.classList.add('hidden');home.classList.remove('hidden');document.body.classList.remove('playing');changeVehicle(selectedVehicle);}
function showModal(html,mode='info'){releaseControls();menuMode=mode;$('modal-content').innerHTML=html;$('modal').classList.remove('hidden');}
function closeModal(){$('modal').classList.add('hidden');menuMode='';}
function resume(){paused=false;closeModal();releaseControls();accumulator=0;audio.ensure();}
function pauseGame(){
  if(!playing||paused)return;paused=true;releaseControls();
  showModal(`<div class="eyebrow">TAKE A BREATHER</div><h2>YOUR ROAD IS WAITING.</h2><p>${net.connected?'Your rider is stopped. Your friends can keep riding.':'Your session is paused.'}</p><div class="control-list"><div><span>Session score</span><b>${Math.floor(state.score)}</b></div><div><span>Wheelie time</span><b>${state.wheelieSeconds.toFixed(1)}s</b></div><div><span>Best lap</span><b>${state.bestLap?formatTime(state.bestLap):'—'}</b></div></div><button id="resume" class="primary">KEEP RIDING <span>↗</span></button><button id="to-garage" class="secondary">BACK TO GARAGE</button>`,'pause');
  $('resume').onclick=resume;$('to-garage').onclick=garage;
}
function help(){
  showModal('<div class="eyebrow">QUICK START</div><h2>FIND YOUR BALANCE.</h2><p>Ride freely, hit ramps, or follow each lime checkpoint to set a lap time. Every completed lap earns 500 points.</p><div class="control-list"><div><span>Throttle / Brake</span><b>W / S or ↑ / ↓</b></div><div><span>Steer</span><b>A / D or ← / →</b></div><div><span>Wheelie on either bike</span><b>Hold GAS + SPACE</b></div><div><span>Reset / Camera / Pause</span><b>R / C / ESC</b></div></div><p>On iPhone, hold the on-screen buttons. Brake to lower the front wheel. Dirt slows the sport bike and kart more than the electric bike. Wheelies and airtime earn bonus points.</p><button id="got-it" class="primary">GOT IT <span>↗</span></button>');$('got-it').onclick=closeModal;
}
function multiplayerMenu(){
  if(net.native){
    showModal(`<div class="eyebrow">RIDE TOGETHER · 2–4 PLAYERS</div><h2>BRING YOUR CREW.</h2><p>Invite friends or find riders through Game Center. You will share <b>${MAPS[selectedMap].name}</b>. Ride freely, compare stunt scores, and chase lap times.</p><p class="fine">Game Center sign-in and an app configured for Game Center are required.</p><button id="match" class="primary">FIND RIDERS <span>↗</span></button>`,'network');
    $('match').onclick=()=>{$('match').disabled=true;$('match').textContent='OPENING GAME CENTER…';net.match(selectedMap);};
  }else{
    showModal('<div class="eyebrow">LIVE MULTIPLAYER · UP TO 4 RIDERS</div><h2>BRING YOUR CREW.</h2><p>Create a private room, then send its code to friends on this server. Each rider chooses their own vehicle.</p><label for="rider-name">YOUR RIDER NAME</label><input id="rider-name" maxlength="20" placeholder="Rider" value="Rider" autocomplete="off"><button id="create-room" class="primary">CREATE ROOM <span>↗</span></button><label for="room-input">OR ENTER A ROOM CODE</label><input id="room-input" placeholder="A1B2C3" maxlength="6" autocapitalize="characters" autocomplete="off"><button id="join-room" class="secondary">JOIN ROOM</button><p class="fine">The iOS app uses Game Center. This browser build uses the included WebSocket server.</p>','network');
    async function connect(join){
      const room=join?$('room-input').value.trim().toUpperCase():'';
      if(join&&!/^[A-F0-9]{6}$/.test(room)){toast('Enter the six-character room code.');return;}
      $('create-room').disabled=$('join-room').disabled=true;
      try{await net.connect({map:selectedMap,room,name:$('rider-name').value});}catch(error){toast(error.message,5000);if($('create-room'))$('create-room').disabled=$('join-room').disabled=false;}
    }
    $('create-room').onclick=()=>connect(false);$('join-room').onclick=()=>connect(true);
  }
}
net.on('connected',m=>{
  clearRemote();if(selectedMap!==m.map)loadMap(m.map);startRide();toast(net.native?'Game Center connected. Ride together!':`ROOM ${m.room} · Share this code with friends.`,6500);
}).on('state',m=>{
  let p=remote.get(m.id);
  if(!p){const model=makeVehicle(m.state.vehicle,'#fb927b');scene.add(model);p={model,current:{...m.state},target:{...m.state},seen:performance.now()};remote.set(m.id,p);}
  if(p.target.vehicle!==m.state.vehicle){discardVehicle(p.model);p.model=makeVehicle(m.state.vehicle,'#fb927b');scene.add(p.model);}
  p.target={...m.state};p.seen=performance.now();p.model.visible=true;
}).on('peerJoin',()=>{updateConnection();toast('A rider joined your session.');}).on('peerLeave',m=>{
  const p=remote.get(m.id);if(p)discardVehicle(p.model);remote.delete(m.id);updateConnection();toast('A rider left the session.');
}).on('disconnected',m=>{clearRemote();updateConnection();toast(m.message||'Multiplayer ended. Continue riding solo.',4500);})
  .on('error',message=>{toast(message,5500);if($('match')){$('match').disabled=false;$('match').textContent='TRY GAME CENTER';}})
  .on('paused',()=>pauseGame());
function updateConnection(){
  $('connection').textContent=net.connected?`${net.native?'GAME CENTER':`ROOM ${net.room}`} · ${net.peers.size+1}/4 RIDERS`:'SOLO SESSION';
}

function releaseControls(){keys.clear();held.clear();document.querySelectorAll('.control.active').forEach(x=>x.classList.remove('active'));}
for(const action of ['left','right','gas','brake','wheelie']){
  const button=$(action);const pointers=new Set();
  button.addEventListener('pointerdown',e=>{if(button.disabled)return;e.preventDefault();audio.ensure();button.setPointerCapture(e.pointerId);pointers.add(e.pointerId);held.set(action,true);button.classList.add('active');});
  const release=e=>{pointers.delete(e.pointerId);if(!pointers.size){held.delete(action);button.classList.remove('active');}};
  for(const event of ['pointerup','pointercancel','lostpointercapture'])button.addEventListener(event,release);
}
function inputs(){return {gas:held.has('gas')||keys.has('KeyW')||keys.has('ArrowUp')?1:0,brake:held.has('brake')||keys.has('KeyS')||keys.has('ArrowDown')?1:0,steer:(held.has('left')||keys.has('KeyA')||keys.has('ArrowLeft')?1:0)-(held.has('right')||keys.has('KeyD')||keys.has('ArrowRight')?1:0),wheelie:held.has('wheelie')||keys.has('Space')};}
// Positive heading turns toward +X; the camera looks forward, so left is +heading.
window.addEventListener('keydown',e=>{
  if(!playing||e.target instanceof HTMLInputElement)return;
  if(['Space','ArrowUp','ArrowDown','ArrowLeft','ArrowRight','Escape'].includes(e.code))e.preventDefault();
  if(e.repeat)return;
  if(e.code==='Escape'){if(paused)resume();else pauseGame();return;}
  if(paused)return;keys.add(e.code);
  if(e.code==='KeyR'){resetState(state);toast('Back on the starting line.');}if(e.code==='KeyC')followMode=(followMode+1)%2;
});
window.addEventListener('keyup',e=>keys.delete(e.code));
window.addEventListener('blur',()=>{releaseControls();if(playing)pauseGame();});
document.addEventListener('visibilitychange',()=>{if(document.hidden){releaseControls();pauseGame();}});
window.addEventListener('contextmenu',e=>e.preventDefault());
$('ride').onclick=startRide;$('help').onclick=help;$('multiplayer').onclick=multiplayerMenu;$('pause').onclick=pauseGame;
$('reset').onclick=()=>{releaseControls();resetState(state);snapCamera();toast('Back on the starting line.');};
$('camera').onclick=()=>{followMode=(followMode+1)%2;toast(followMode?'Wide chase camera':'Close chase camera',1200);};
$('modal-close').onclick=()=>menuMode==='pause'?resume():closeModal();
document.querySelectorAll('[data-map]').forEach(el=>el.onclick=()=>{if(!playing)loadMap(el.dataset.map);});
document.querySelectorAll('[data-vehicle]').forEach(el=>el.onclick=()=>{if(!playing)changeVehicle(el.dataset.vehicle);});

const audio={enabled:false,ctx:null,osc:null,gain:null,
  ensure(){if(!this.enabled)return;try{if(!this.ctx){this.ctx=new(window.AudioContext||window.webkitAudioContext)();this.osc=this.ctx.createOscillator();this.gain=this.ctx.createGain();const filter=this.ctx.createBiquadFilter();filter.type='lowpass';filter.frequency.value=700;this.osc.type='sawtooth';this.osc.connect(filter);filter.connect(this.gain);this.gain.connect(this.ctx.destination);this.gain.gain.value=0;this.osc.start();}this.ctx.resume().catch(()=>{});}catch{}},
  update(){if(!this.ctx)return;const live=this.enabled&&playing&&!paused;const rpm=state.speed/VEHICLES[selectedVehicle].max;this.osc.type=selectedVehicle==='surron'?'sine':'sawtooth';this.osc.frequency.setTargetAtTime((selectedVehicle==='surron'?80:32)+rpm*(selectedVehicle==='surron'?270:140),this.ctx.currentTime,.07);this.gain.gain.setTargetAtTime(live?.025+rpm*.012:0,this.ctx.currentTime,.08);}
};
$('sound').onclick=()=>{audio.enabled=!audio.enabled;$('sound').innerHTML=`♪ <span>SOUND ${audio.enabled?'ON':'OFF'}</span>`;$('sound').setAttribute('aria-label',audio.enabled?'Disable sound':'Enable sound');audio.ensure();};

const mini=$('minimap').getContext('2d');
function drawMinimap(){
  mini.clearRect(0,0,260,260);const t=world.track,scale=.68,ox=130,oz=130;
  mini.strokeStyle='#78918c';mini.lineWidth=5;mini.lineJoin='round';mini.beginPath();t.forEach((p,i)=>i?mini.lineTo(ox+p.x*scale,oz+p.z*scale):mini.moveTo(ox+p.x*scale,oz+p.z*scale));mini.closePath();mini.stroke();
  const cp=MAPS[selectedMap].points[state.nextCheckpoint];mini.fillStyle='#c6ff38';mini.beginPath();mini.arc(ox+cp[0]*scale,oz+cp[1]*scale,6,0,Math.PI*2);mini.fill();
  for(const p of remote.values()){mini.fillStyle='#ff9779';mini.beginPath();mini.arc(ox+p.current.x*scale,oz+p.current.z*scale,4,0,Math.PI*2);mini.fill();}
  mini.save();mini.translate(ox+state.x*scale,oz+state.z*scale);mini.rotate(Math.PI-state.heading);mini.fillStyle='#ffffff';mini.beginPath();mini.moveTo(0,-8);mini.lineTo(5,5);mini.lineTo(0,3);mini.lineTo(-5,5);mini.closePath();mini.fill();mini.restore();
}
function updateHUD(){
  const speed=Math.round(state.speed*3.6);$('speed').textContent=speed;$('speed-bar').style.width=`${clamp(state.speed/VEHICLES[selectedVehicle].max*100,0,100)}%`;
  $('gear').replaceChildren(document.createTextNode(speed<1?'N':selectedVehicle==='surron'?'E':String(Math.min(6,1+Math.floor(speed/35)))),Object.assign(document.createElement('span'),{textContent:VEHICLES[selectedVehicle].name}));
  $('lap-time').textContent=formatTime(state.lapElapsed);$('checkpoint').textContent=`CHECKPOINT ${state.nextCheckpoint===0?MAPS[selectedMap].points.length:state.nextCheckpoint} / ${MAPS[selectedMap].points.length}`;
  $('best-lap').textContent=state.bestLap?`BEST ${formatTime(state.bestLap)}`:'SET YOUR FIRST LAP';$('lap-count').textContent=`LAP ${String(state.lap+1).padStart(2,'0')}`;
  $('score').textContent=String(Math.floor(state.score)).padStart(5,'0');
  const stunt=state.wheelieRun>.15||!state.grounded;$('stunt').classList.toggle('hidden',!stunt);
  if(stunt){$('stunt').firstElementChild.textContent=state.grounded?'BALANCE POINT':'TAKE FLIGHT';$('stunt').querySelector('b').innerHTML=`${state.grounded?'WHEELIE':'AIRTIME'} <span>${(state.grounded?state.wheelieRun:state.airTime).toFixed(1)}</span>s`;$('stunt-points').textContent=state.grounded?`${Math.round(25+Math.min(state.wheelieRun,5)*10)} PTS / SEC`:'STICK THE LANDING';}
  $('roster').replaceChildren();
  if(net.connected){const scores=[{name:'YOU',score:Math.floor(state.score)},...[...remote.values()].map(p=>({name:p.target.name,score:p.target.score}))].sort((a,b)=>b.score-a.score);
    for(const p of scores){const row=document.createElement('div'),name=document.createElement('span'),score=document.createElement('b');name.textContent=p.name;score.textContent=p.score;row.append(name,score);$('roster').append(row);}}
  drawMinimap();
}
function resize(){renderer.setSize(innerWidth,innerHeight,false);camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();}
window.addEventListener('resize',()=>{resize();releaseControls();});resize();loadMap('coast');
$('loading').classList.add('hidden');

function frame(now){
  requestAnimationFrame(frame);const dt=Math.min((now-last)/1000||STEP,.05);last=now;
  if(playing&&!paused&&!(innerHeight>innerWidth&&innerWidth<700)){
    accumulator+=dt;let ticks=0;while(accumulator>=STEP&&ticks++<4){
      const lap=state.lap;step(state,inputs(),STEP);accumulator-=STEP;
      if(state.lap>lap){bests[`${selectedMap}/${selectedVehicle}`]=state.bestLap;saveBest();toast(`LAP ${state.lap} · ${formatTime(state.lastLap)} · +500 points`,4000);}
    }
  }else accumulator=0;
  if(playing){
    poseVehicle(vehicle,state,paused?0:dt);
    const h=state.heading,wide=followMode?1.5:1;
    cameraTarget.set(state.x-Math.sin(h)*(7.8+state.speed*.045)*wide,state.y+(3.1+state.speed*.025)*wide,state.z-Math.cos(h)*(7.8+state.speed*.045)*wide);
    camera.position.lerp(cameraTarget,1-Math.exp(-dt*7));lookTarget.set(state.x+Math.sin(h)*4,state.y+1.2,state.z+Math.cos(h)*4);camera.lookAt(lookTarget);
    const cp=MAPS[selectedMap].points[state.nextCheckpoint];checkpointHalo.visible=true;checkpointHalo.position.set(cp[0],.18+Math.sin(now*.003)*.06,cp[1]);checkpointHalo.scale.setScalar(1+Math.sin(now*.003)*.1);
    camera.fov=T.MathUtils.lerp(camera.fov,58+state.speed*.13,dt*3);
    hudClock+=dt;if(hudClock>.075){hudClock=0;updateHUD();}
  }else{
    checkpointHalo.visible=false;const h=state.heading+.25+Math.sin(now*.0002)*.12;
    const sx=Math.sin(h),cz=Math.cos(h);cameraTarget.set(state.x-sx*4.8+cz*4.8,2.6,state.z-cz*4.8-sx*4.8);
    camera.position.lerp(cameraTarget,1-Math.exp(-dt*3));camera.lookAt(state.x,1.0,state.z);camera.fov=T.MathUtils.lerp(camera.fov,42,dt*3);poseVehicle(vehicle,{...state,pitch:selectedVehicle==='kart'?0:.13,lean:0},0);
  }
  for(const p of remote.values()){
    interpolateRemote(p.current,p.target,dt);poseVehicle(p.model,p.current,dt);p.model.visible=now-p.seen<12000;
  }
  sun.position.set(state.x-35,65,state.z-30);sun.target.position.set(state.x,0,state.z);sun.target.updateMatrixWorld();
  camera.updateProjectionMatrix();renderer.render(scene,camera);audio.update();
  if(playing&&net.connected){sendClock+=dt;if(sendClock>=1/15){sendClock=0;const s=snapshot(state);if(paused)s.speed=0;net.send(s);}}
}
requestAnimationFrame(frame);
// Read-only diagnostics let automated tests inspect the live build without changing gameplay.
window.Redline={get state(){return {...state};},get playing(){return playing;},get paused(){return paused;},get map(){return selectedMap;},get vehicle(){return selectedVehicle;},get peers(){return [...remote.values()].map(p=>({...p.target}));},get room(){return net.room;},get connected(){return net.connected;},get renderStats(){return {...renderer.info.render};}};
