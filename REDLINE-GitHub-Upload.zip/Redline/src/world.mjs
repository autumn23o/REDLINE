import * as T from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { MAPS, VEHICLES, getTrack, getScenery, seeded } from './core.mjs';

const materials=new Map(),geometries=new Map();
function mat(color,rough=.78,metal=.05,emissive=false) {
  const key=[color,rough,metal,emissive].join('/');
  if(!materials.has(key))materials.set(key,new T.MeshStandardMaterial({color,roughness:rough,metalness:metal,...(emissive?{emissive:color,emissiveIntensity:.7}:{})}));
  return materials.get(key);
}
function geo(key,make){if(!geometries.has(key))geometries.set(key,make());return geometries.get(key);}
const boxG=()=>geo('box',()=>new T.BoxGeometry(1,1,1));
function mesh(parent,g,m,x=0,y=0,z=0){const n=new T.Mesh(g,m);n.position.set(x,y,z);n.castShadow=true;n.receiveShadow=true;parent.add(n);return n;}
function box(p,c,x,y,z,w,h,d){const n=mesh(p,boxG(),mat(c),x,y,z);n.scale.set(w,h,d);return n;}
function cylinder(p,c,x,y,z,r,h,sides=10){return mesh(p,geo(`cyl${r}${h}${sides}`,()=>new T.CylinderGeometry(r,r,h,sides)),mat(c),x,y,z);}
function sphere(p,c,x,y,z,r,detail=1){return mesh(p,geo(`ico${r}${detail}`,()=>new T.IcosahedronGeometry(r,detail)),mat(c),x,y,z);}
function rod(p,c,a,b,r=.06){const av=new T.Vector3(...a),bv=new T.Vector3(...b),d=bv.clone().sub(av),n=cylinder(p,c,0,0,0,r,d.length(),8);n.position.copy(av.add(bv).multiplyScalar(.5));n.quaternion.setFromUnitVectors(new T.Vector3(0,1,0),d.normalize());return n;}
function label(text,color='#c6ff38',width=512,height=128){
  const c=document.createElement('canvas');c.width=width;c.height=height;const ctx=c.getContext('2d');
  ctx.fillStyle='#15222a';ctx.fillRect(0,0,width,height);ctx.fillStyle=color;ctx.font=`900 ${Math.round(height*.48)}px system-ui`;ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText(text,width/2,height/2,width-24);
  const t=new T.CanvasTexture(c);t.colorSpace=T.SRGBColorSpace;return new T.MeshBasicMaterial({map:t,side:T.DoubleSide});
}

export function makeVehicle(kind='moto',color=null) {
  const spec=VEHICLES[kind],paint=color||spec.color,root=new T.Group(),lean=new T.Group(),body=new T.Group(),wheels=[];
  root.add(lean);lean.add(body);
  const rubber=0x13191d,alloy=0x677782,black=0x1c242d;
  const wheel=(x,y,z,r,width)=>{
    const spin=new T.Group();spin.position.set(x,y,z);body.add(spin);
    const tire=mesh(spin,geo(`tire${r}${width}`,()=>new T.CylinderGeometry(r,r,width,14)),mat(rubber));tire.rotation.z=Math.PI/2;
    const hub=mesh(spin,geo(`hub${r}${width}`,()=>new T.CylinderGeometry(r*.57,r*.57,width+.012,12)),mat(alloy,.33,.65));hub.rotation.z=Math.PI/2;
    for(let side of [-1,1]){const stripe=box(spin,0xd4dfdb,side*(width/2+.01),0,0,.012,r*1.15,.065);}
    wheels.push({node:spin,r});return spin;
  };
  if(kind==='kart'){
    box(body,black,0,.28,0,1.33,.15,1.85);
    box(body,paint,0,.48,.76,.80,.23,.55);
    box(body,paint,0,.63,1.05,1.48,.12,.17);
    box(body,paint,-.68,.40,0,.3,.27,.95);box(body,paint,.68,.40,0,.3,.27,.95);
    box(body,black,0,.57,-.35,.64,.6,.62);
    box(body,alloy,.53,.45,-.72,.32,.4,.38);
    for(const x of [-.76,.76])for(const z of [-.69,.69])wheel(x,.25,z,.26,.25);
    rod(body,alloy,[-.8,.23,-.7],[.8,.23,-.7],.045);
    box(body,0xdee6df,0,.65,.78,.38,.035,.24);
    rod(body,black,[0,.4,.15],[0,.95,.39],.04);
    const steering=mesh(body,geo('steer',()=>new T.TorusGeometry(.18,.025,6,12)),mat(black),0,1,.38);steering.rotation.x=-.6;
    box(body,0x313a49,0,.85,-.22,.43,.51,.35);
    sphere(body,0xf0f4e8,0,1.31,-.2,.25,2);box(body,0x182c3c,0,1.32,.012,.40,.13,.08);
    for(const side of [-1,1]){rod(body,0x303d4a,[side*.22,1,-.15],[side*.18,.94,.38],.075);rod(body,0x283445,[side*.16,.65,-.2],[side*.23,.40,.51],.09);}
  }else{
    const e=kind==='surron',wb=spec.wheelbase,r=e?.38:.34,back=-wb/2,front=wb/2;
    // Origin at the rear contact patch: pitching raises only the front end.
    body.position.z=back;
    wheel(0,r,0,r,e?.15:.23);wheel(0,r,wb,r,e?.12:.21);
    rod(body,alloy,[0,r,.03],[0,.65,wb*.52],.07);
    rod(body,paint,[0,.62,.35],[0,1.0,wb*.66],.055);
    rod(body,paint,[0,1.0,wb*.66],[0,.49,wb*.60],.055);
    rod(body,paint,[0,.49,wb*.60],[0,.62,.35],.055);
    for(const x of [-.1,.1])rod(body,alloy,[x,r,wb],[x,1.05,wb*.80],.043);
    box(body,e?0x222d35:paint,0,.80,wb*.54,e?.21:.48,e?.49:.32,e?.40:.66);
    box(body,black,0,1.01,wb*.32,e?.25:.39,.12,.63);
    box(body,paint,0,.85,.02,e?.23:.35,.07,.50);
    if(!e){box(body,paint,0,.61,wb*.56,.43,.28,.56);rod(body,0x969d99,[.25,.48,.10],[.25,.52,.60],.08);}
    rod(body,black,[-.36,1.13,wb*.77],[.36,1.13,wb*.77],.033);
    const light=box(body,0xfff6d2,0,.98,wb*.90,.18,.10,.06);light.material=mat(0xfff6d2,.4,.1,true);
    box(body,0xff4b49,0,1.02,0,.17,.05,.04).material=mat(0xff4b49,.4,.1,true);
    // Helmet, torso, articulated arms and boots make each silhouette readable.
    const torso=box(body,0x25323b,0,1.36,wb*.40,.40,.53,.28);torso.rotation.x=.22;
    sphere(body,0xeeeede,0,1.80,wb*.48,.245,2);box(body,0x132837,0,1.83,wb*.48+.206,.37,.12,.07);
    box(body,paint,0,1.86,wb*.48-.22,.22,.055,.04);
    for(const side of [-1,1]) {
      rod(body,0x293640,[side*.20,1.56,wb*.45],[side*.31,1.30,wb*.64],.065);
      rod(body,0x293640,[side*.31,1.30,wb*.64],[side*.33,1.15,wb*.77],.06);
      sphere(body,0x10171c,side*.33,1.15,wb*.77,.072);
      rod(body,0x25323e,[side*.15,1.1,wb*.26],[side*.25,.83,wb*.59],.095);
      rod(body,0x25323e,[side*.25,.83,wb*.59],[side*.25,.42,wb*.42],.075);
      box(body,0x121a20,side*.25,.41,wb*.48,.14,.13,.29);
    }
    body.position.y=r;
    for(const part of body.children)part.position.y-=r;
  }
  const shadow=mesh(root,geo('shadow',()=>new T.CircleGeometry(1.15,24)),new T.MeshBasicMaterial({color:0x0a1720,transparent:true,opacity:.24,depthWrite:false}),0,.028,0);shadow.rotation.x=-Math.PI/2;shadow.scale.set(.8,1.3,1);shadow.castShadow=false;
  root.userData={body,lean,wheels,shadow,kind}; return root;
}
export function poseVehicle(root,s,dt=0) {
  root.position.set(s.x,s.y,s.z);root.rotation.y=s.heading;
  root.userData.lean.rotation.z=s.lean||0;
  root.userData.body.rotation.x=-(s.pitch||0);
  for(const w of root.userData.wheels)w.node.rotation.x+=(s.speed||0)*dt/w.r;
  root.userData.shadow.visible=s.y<.5;
}
function roadMesh(points,width,height,color,offset=0) {
  const pos=[],uv=[],idx=[];
  for(let i=0;i<=points.length;i++){
    const p=points[i%points.length],a=points[(i+points.length-1)%points.length],b=points[(i+1)%points.length],dx=b.x-a.x,dz=b.z-a.z,len=Math.hypot(dx,dz),nx=dz/len,nz=-dx/len;
    for(const s of [-1,1]){const o=s*width/2+offset;pos.push(p.x+nx*o,height,p.z+nz*o);uv.push(s===-1?0:1,i/5);}
    if(i<points.length){let n=i*2;idx.push(n,n+2,n+1,n+1,n+2,n+3);}
  }
  const g=new T.BufferGeometry();g.setAttribute('position',new T.Float32BufferAttribute(pos,3));g.setAttribute('uv',new T.Float32BufferAttribute(uv,2));g.setIndex(idx);g.computeVertexNormals();
  return new T.Mesh(g,mat(color));
}
export function makeWorld(mapKey) {
  const map=MAPS[mapKey],root=new T.Group(),track=getTrack(mapKey),gates=[],lampLights=[];
  const terrain=box(root,map.ground,0,-.35,0,510,.7,510);terrain.receiveShadow=true;
  root.add(roadMesh(track,map.width+2,.025,mapKey==='desert'?0xad7953:0xd6d3ba));
  root.add(roadMesh(track,map.width,.045,mapKey==='desert'?0xb18059:0x3e4b50));
  if(mapKey!=='desert'){
    root.add(roadMesh(track,.13,.06,0xe6e5cc,map.width/2-.7));root.add(roadMesh(track,.13,.06,0xe6e5cc,-map.width/2+.7));
    for(let i=0;i<track.length;i+=3){const p=track[i],q=track[(i+1)%track.length],n=box(root,0xe8dbab,p.x,.069,p.z,.14,.01,2.4);n.rotation.y=Math.atan2(q.x-p.x,q.z-p.z);}
  }
  // Starting line and checkpoints all use the same authored path as the simulation.
  for(let i=0;i<map.points.length;i++){
    const p=track[i*20],q=track[(i*20+1)%track.length],heading=Math.atan2(q.x-p.x,q.z-p.z),gate=new T.Group();gate.position.set(p.x,0,p.z);gate.rotation.y=heading;
    for(const side of [-1,1]){
      box(gate,0x24383d,side*(map.width/2+.4),2.6,0,.28,5.2,.28);
      const glow=box(gate,map.color,side*(map.width/2+.4),3.2,0,.32,2.6,.32);glow.material=mat(map.color,.7,0,true);
    }
    if(i===0){box(gate,0x162930,0,5.1,0,map.width+1.2,.8,.4);const sign=mesh(gate,new T.PlaneGeometry(7,.65),label('R E D L I N E'),0,5.12,-.22);sign.rotation.y=Math.PI;for(let x=-6;x<6;x++)for(let z=0;z<2;z++)box(gate,(x+z)%2?0xeeeece:0x253640,x,.09,z-.5,1,.02,1);}
    root.add(gate);gates.push(gate);
  }
  // Ramps are physical wedges, not scenery-only props.
  for(const r of map.ramps){
    const g=new T.BufferGeometry(),w=r.width/2,l=r.length/2,h=r.height;
    g.setAttribute('position',new T.Float32BufferAttribute([-w,0,-l,w,0,-l,w,h,l,-w,h,l,-w,0,l,w,0,l],3));
    g.setIndex([0,3,1,1,3,2,0,4,3,1,2,5,3,4,5,3,5,2]);g.computeVertexNormals();
    const m=mesh(root,g,mat(mapKey==='city'?0x7672a1:0x8a795f),r.x,.05,r.z);m.rotation.y=r.heading;
    for(let side of [-1,1]){const stripe=rod(root,map.color,[r.x+Math.cos(r.heading)*side*w-Math.sin(r.heading)*l,.12,r.z-Math.sin(r.heading)*side*w-Math.cos(r.heading)*l],[r.x+Math.cos(r.heading)*side*w+Math.sin(r.heading)*l,h+.12,r.z-Math.sin(r.heading)*side*w+Math.cos(r.heading)*l],.09);}
  }
  const r=seeded(728);
  for(const o of getScenery(mapKey)){
    if(o.kind==='pavilion'){
      box(root,0xc4baa3,o.x,o.h/2,o.z,o.w,o.h,o.d);box(root,0x344f51,o.x,3.5,o.z,16,.4,9);
      mesh(root,new T.PlaneGeometry(7,1.1),label('PACIFIC RUN'),o.x,2.2,o.z+3.52);
    }else if(o.kind==='building'){
      const color=o.tone>.5?0x364a59:0x455465;
      box(root,color,o.x,o.h/2,o.z,o.w,o.h,o.d);
      box(root,0x263847,o.x,o.h+.3,o.z,o.w+.5,.6,o.d+.5);
      const lights=o.tone>.5?0x91b4b8:0xffd496;
      for(let y=3;y<o.h-2;y+=4.8){
        for(const side of [-1,1]){
          const a=box(root,lights,o.x,y,o.z+side*(o.d/2+.02),o.w*.73,.65,.03);a.material=mat(lights,.9,0,true);
          const b=box(root,lights,o.x+side*(o.w/2+.02),y,o.z,.03,.65,o.d*.73);b.material=mat(lights,.9,0,true);
        }
      }
    }else if(o.kind==='palm'){
      const trunk=cylinder(root,0x777161,o.x,o.h/2,o.z,.23,o.h,7);trunk.rotation.z=.08;
      for(let a=0;a<6;a++){const leaf=mesh(root,geo('leaf',()=>new T.ConeGeometry(1.0,4.4,4)),mat(0x4c7970),o.x,o.h,o.z);leaf.rotation.set(Math.sin(a*Math.PI/3)*1.16,0,Math.cos(a*Math.PI/3)*1.16);leaf.position.x+=Math.cos(a*Math.PI/3)*1.25;leaf.position.z+=Math.sin(a*Math.PI/3)*1.25;}
    }else if(o.kind==='cactus'){
      cylinder(root,0x687e58,o.x,o.h*.3,o.z,.36,o.h*.6,7);
      for(let side of [-1,1]){rod(root,0x687e58,[o.x,o.h*.3,o.z],[o.x+side*1.1,o.h*.3,o.z],.22);cylinder(root,0x687e58,o.x+side*1.1,o.h*.42,o.z,.22,o.h*.24,7);}
    }else{const n=mesh(root,geo('rock',()=>new T.IcosahedronGeometry(1,0)),mat(mapKey==='desert'?0xaa6b4d:0x7d9188),o.x,o.h*.36,o.z);n.scale.set(o.r,o.h*.65,o.r*.85);n.rotation.y=o.tone*6;}
  }
  if(mapKey==='coast'){
    box(root,0x71b9c7,244,-.12,0,155,.12,510);
    box(root,0xd9c5a1,158,-.04,0,18,.08,510);
    for(let i=0;i<28;i++)box(root,0xc0e2da,172+r()*125,.005,-240+i*18,14+r()*20,.015,.16);
  }
  if(mapKey==='desert')for(let i=0;i<22;i++){const a=i/22*Math.PI*2,rad=285+r()*25;const m=mesh(root,geo('mesa',()=>new T.CylinderGeometry(.6,1,1,5)),mat(i%2?0xb37456:0x9c6652),Math.sin(a)*rad,7,Math.cos(a)*rad);m.scale.set(14+r()*16,15+r()*26,15+r()*10);}
  // Roadside lamps and distance markers give speed a visible reference.
  for(let i=0;i<track.length;i+=9){
    const p=track[i],q=track[(i+1)%track.length],dx=q.x-p.x,dz=q.z-p.z,len=Math.hypot(dx,dz),x=p.x+dz/len*(map.width/2+2),z=p.z-dx/len*(map.width/2+2);
    if(mapKey==='city'){
      cylinder(root,0x263c4a,x,3.5,z,.08,7,6);const glow=box(root,0xf5d8a0,x,7,z,1,.12,.4);glow.material=mat(0xf5d8a0,.5,0,true);
    }else{box(root,0xe6dec8,x,.6,z,.13,1.2,.16);box(root,mapKey==='desert'?0x6f3e31:0x759a8c,x,.97,z,.14,.22,.17);}
  }
  // Batch static scenery by material; thousands of windows become a few draw calls.
  root.updateMatrixWorld(true);
  const batches=new Map(),shared=new Set(geometries.values()),originals=new Set();
  root.traverse(n=>{if(n.isMesh){let g=n.geometry.clone();g.applyMatrix4(n.matrixWorld);if(g.index){const indexed=g;g=g.toNonIndexed();indexed.dispose();}const group=batches.get(n.material)||[];group.push(g);batches.set(n.material,group);if(!shared.has(n.geometry))originals.add(n.geometry);}});
  root.clear();
  for(const [material,parts] of batches){const g=mergeGeometries(parts);parts.forEach(p=>p.dispose());const m=new T.Mesh(g,material);m.castShadow=true;m.receiveShadow=true;root.add(m);}
  originals.forEach(g=>g.dispose());
  return {root,gates:[],track,map};
}
export function disposeWorld(world){
  // Shared cached meshes/materials are kept; dispose only unique resources.
  const sharedG=new Set(geometries.values()),sharedM=new Set(materials.values());
  world.root.traverse(n=>{if(n.isMesh){if(!sharedG.has(n.geometry))n.geometry.dispose();if(!sharedM.has(n.material)){n.material.map?.dispose();n.material.dispose();}}});
}

export function makeRenderer(canvas) {
  const renderer=new T.WebGLRenderer({canvas,antialias:true,powerPreference:'high-performance'});
  renderer.setPixelRatio(Math.min(devicePixelRatio,1.6));renderer.shadowMap.enabled=true;renderer.shadowMap.type=T.PCFSoftShadowMap;renderer.outputColorSpace=T.SRGBColorSpace;renderer.toneMapping=T.ACESFilmicToneMapping;renderer.toneMappingExposure=1.18;
  const scene=new T.Scene(),camera=new T.PerspectiveCamera(53,1,.1,540);
  const ambient=new T.HemisphereLight(0xeaf8ff,0x737057,2.3);scene.add(ambient);
  const sun=new T.DirectionalLight(0xffedcf,3.1);sun.position.set(-35,65,-30);sun.castShadow=true;sun.shadow.mapSize.set(1024,1024);sun.shadow.camera.left=-32;sun.shadow.camera.right=32;sun.shadow.camera.top=32;sun.shadow.camera.bottom=-32;sun.shadow.camera.far=160;sun.shadow.normalBias=.04;sun.shadow.bias=-.0002;scene.add(sun);scene.add(sun.target);
  return {renderer,scene,camera,sun,ambient};
}
export { T };
